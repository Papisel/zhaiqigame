/*
 Navicat MySQL Data Transfer

 Source Server         : database_1
 Source Server Type    : MySQL
 Source Server Version : 50742
 Source Host           : localhost:3306
 Source Schema         : zhanqigame

 Target Server Type    : MySQL
 Target Server Version : 50742
 File Encoding         : 65001

 Date: 09/05/2024 16:11:42
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for gamerecords
-- ----------------------------
DROP TABLE IF EXISTS `gamerecords`;
CREATE TABLE `gamerecords`  (
  `record` int(50) NOT NULL,
  `ID1` int(50) NOT NULL,
  `ID2` int(50) NOT NULL,
  `time` int(50) NULL DEFAULT NULL,
  `winner` int(50) NULL DEFAULT NULL,
  PRIMARY KEY (`record`) USING BTREE,
  INDEX `ID1`(`ID1`) USING BTREE,
  INDEX `ID2`(`ID2`) USING BTREE,
  CONSTRAINT `ID1` FOREIGN KEY (`ID1`) REFERENCES `users` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `ID2` FOREIGN KEY (`ID2`) REFERENCES `users` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

SET FOREIGN_KEY_CHECKS = 1;
