from queue import Queue


# 获取单位的可移动范围
def bfs(scene, unit):
    # 单位初始位置
    start = tuple(unit.coordinate)
    # 初始化
    frontier = Queue()
    frontier.put((start, 0))
    reached = set()
    reached.add(start)
    came_from = dict()
    came_from[start] = None
    # 结果
    move_target, battle_target = [], []
    # 坐标和层
    while not frontier.empty():
        # 遍历时单位当前位置
        current = frontier.get()
        for next_ in neighbors(scene, current[0]):
            # 单位到不了
            if not is_reach_able(unit, current[1] + 1):
                # 超过了机动范围和开火范围
                continue
            # 没到过的地块
            if next_ not in reached:
                reached.add(next_)
            else:
                continue
            # 单位进不去
            if not is_enter_able(scene, unit, next_):
                # 存在敌军
                if faction := scene.is_unit_here(next_):
                    if faction != unit.faction:
                        # if current[0] in move_target or current[0] == start:
                        # 标记敌人
                        battle_target.append(next_)
                        # 从哪里来
                        came_from[next_] = current[0]
                continue
            # 单位可移入
            else:
                frontier.put((next_, current[1] + 1))
                # 从哪里来
                came_from[next_] = current[0]
                # 可作为移动路径最终点
                if can_stay(scene, unit, next_, current[1] + 1):
                    move_target.append(next_)
    # 返回结果
    return came_from, move_target, battle_target


# 广度优先算法寻路
def bfs_recursive(bfs_res, unit, goal, mode='move'):
    # 结果
    came_from, move_target, battle_target = bfs_res
    # 单位初始位置
    start = tuple(unit.coordinate)
    # 存储路径
    path = []
    # 非有效点
    if (goal not in move_target) and (mode == 'move'):
        return path
    if mode == 'battle':
        goal = tuple(goal)
    # 反向寻路
    current = goal
    while current != start:
        path.append(current)
        current = came_from[current]
    path.append(start)  # optional
    path.reverse()  # optional

    return path


# 路径转行动
def path2action(path, mode):
    res = []
    for i in range(len(path) - 1):
        c, n = path[i], path[i + 1]
        vector = (n[0] - c[0], n[1] - c[1])
        match vector:
            case (1, 0):
                res.append(("move", 0))
            case (0, 1):
                res.append(("move", 1))
            case (-1, 0):
                res.append(("move", 2))
            case (0, -1):
                res.append(("move", 3))
    # 战斗
    if mode == "battle":
        action = ("battle", res[-1][1])
        res.pop(-1)
        res.append(action)
    return res


# 邻居
def neighbors(scene, current):
    # 遍历
    res = []
    for direction in [(1, 0), (0, 1), (-1, 0), (0, -1)]:
        pos = (current[0] + direction[0], current[1] + direction[1])
        # 确实有这个地块
        if pos in scene.RBlocks:
            res.append(pos)
    # 返回值
    return res


# 单位到不了
def is_reach_able(unit, distance, battle=True):
    # 开火距离
    if battle:
        move = unit.get_stats()["move"] + 1
    # 机动距离
    else:
        move = unit.get_stats()["move"]
    # 移动能力
    if distance > move:
        return False
    else:
        return True


# 单位是否可进入
def is_enter_able(scene, unit, next_):
    # 这个地块存在单位，是敌方，不可进入
    if faction := scene.is_unit_here(next_):
        # if faction != unit.faction:
        return False
    # 单位的移动方式与地形
    move_type = unit.get_stats()["move_type"]
    terrain = scene.RBlocks[next_].get_stats()["type"]
    # 地形禁止进入
    if terrain == 0:
        return False
    # 空军都过
    elif move_type == 3:
        return True
    # 陆军过陆地，海军过海洋
    elif move_type == terrain:
        return True
    else:
        return False


# 单位可将此格作为机动终点
def can_stay(scene, unit, next_, distance):
    # 有单位在上面不能作为终点
    if scene.is_unit_here(next_):
        return False
    # 超过机动距离
    if not is_reach_able(unit, distance, False):
        return False
    return True
