from queue import Queue

from PySide6.QtCore import QTimer
from PySide6.QtGui import QColor, QBrush, Qt
from PySide6.QtWidgets import QGraphicsScene

from Block import Block
from Cover import Cover
from Unit import Unit
import Battle
import Tool


# 绘制场景，屏幕中的内容
class GridScene(QGraphicsScene):
    def __init__(self, parent):
        super().__init__(parent)
        # 设置背景颜色
        self.setBackgroundBrush(QBrush(QColor("#000000")))
        # 设置背景大小
        length = 56 * 20  # 注意长宽，左上角开始，右下角结束，过短将在原点结束
        self.setSceneRect(-length, -length, 4 * length, 4 * length)
        # 所有的地形格
        self.RBlocks: [tuple, Block] = {}
        # 所有的单位格
        self.UBlocks: [int, Block] = {}
        # 更高一层的标记格
        self.CBlocks: [tuple, Block] = {}
        # 单位状态更新
        self.index = 0
        self.action_unit = None
        self.actions_queue = Queue()
        self.remove_queue = Queue()
        self.actions = []
        self.timer = QTimer()
        self.offset = 0
        # 战斗双方
        self.battle_unit = ()

    # 导入地图并渲染
    def load(self, map_path, faction):
        # 导入地形地图
        if isinstance(map_path, str):
            map = Tool.load_json(map_path)
            b_map = map["block_map"]
            u_map = map["unit_map"]
        # 不是地图路径，地图本体
        else:
            b_map = map_path["block_map"]
            u_map = map_path["unit_map"]
        # 导入地形
        w, h = b_map["size"]
        for x in range(w):
            for y in range(h):
                # 修改后，符合文件的格式按照其视觉预期显示地图
                # 只是修改读取地图文件时候的顺序，最终得到这张地图是没有影响的
                # 不过有一点，就是之后如果加一张地图编辑功能，那要记得注意这个
                # 或者再给这里改回来，毕竟现在视为了测试用
                # 这段注释留一下，避免后面忘了
                # item = Block((x, y), basic["block"][x][y])
                item = Block((x, y), b_map["block"][y][x])
                # 将地块类型
                self.addItem(item)
                self.RBlocks[(x, y)] = item  # 记录方格信息
        # 导入单位
        index = 0
        for unit in u_map['unit']:
            item = Unit(index, unit)
            item.setZValue(item.coordinate[1])
            # 依据阵营更新单位行动显示
            if not self.views()[0].parent().editor_mode:
                item.update_ready_item(self.parent().faction)
            self.addItem(item)
            self.UBlocks[index] = item
            index += 1
        # 最高一层，即地图高，放置标记覆盖
        for x in range(w):
            for y in range(h):
                item = Cover((x, y))
                item.setZValue(h)
                self.CBlocks[(x, y)] = item  # 记录方格信息
                self.addItem(item)

    # 增加一个单位
    def add_unit(self, data):
        index = len(self.UBlocks)
        # 添加到场景中
        item = Unit(index, data)
        item.setZValue(item.coordinate[1])
        self.addItem(item)
        self.UBlocks[index] = item

    # 移除一个单位
    def remove_unit(self, unit):
        faction = unit.faction
        # 删除单位
        # 此处只在哈希表中删除该单位索引
        del self.UBlocks[unit.index]
        # 开始胜利判断
        for unit in self.UBlocks.values():
            if faction == unit.faction:
                break
        else:
            return faction

    def remove_unit_for_editor(self, unit):
        # 删除单位
        del self.UBlocks[unit.index]
        self.removeItem(unit)

    # 战斗移除
    def remove_battle_unit(self, defender, Firster_index):
        # 一次战斗只能移除一个单位
        if defender.get_cur_stats()["health"] <= 0:
            res = self.remove_unit(defender)
            if defender.index == Firster_index:
                # 如果有回击，并且先攻者会被击败，就暂存先攻者实例
                self.action_unit = defender
            return res, defender
        # # 防御方存在
        # elif attacker.get_cur_stats()["health"] <= 0:
        #     res = self.remove_unit(attacker)
        #     self.action_unit = attacker
        #     return res, attacker
        else:
            return None, None

    def battle_action(self, attacker, defender, Firster_index):
        defender_damage = Battle.damage_calc(attacker, defender)
        # 攻击方造成输出
        defender.damage += defender_damage
        res, remove_unit = self.remove_battle_unit(defender, Firster_index)
        self.battle_unit = ()
        # 胜负裁定
        if res:
            self.views()[0].parent().win_or_lost(res)
        return remove_unit

    # 这里有单位吗
    def is_unit_here(self, pos, isAI=False):
        for unit in self.UBlocks.values():
            if pos == tuple(unit.coordinate):
                if isAI:
                    return unit
                faction = unit.faction
                return faction
        return ""

    # 单位行动范围显示
    def display_unit_range(self, bfs_res):
        # 结果
        came_from, move_target, battle_target = bfs_res
        for pos in move_target:
            item = self.CBlocks[pos]
            item.set_mode('move')
        for pos in battle_target:
            item = self.CBlocks[pos]
            item.set_mode('battle')

    # 清理行动范围显示
    def clear_unit_display(self):
        for item in self.CBlocks.values():
            item.clear_mode()

    # 更新一方的全部单位的可行动
    def update_ready_unit(self, faction, ready):
        for unit in self.UBlocks.values():
            # if unit.faction == faction:
            if ready != unit.ready:
                unit.reverse_ready(faction)

    # 更新单位
    # 3个默认参数
    # index：攻击者单位索引,
    # actions：动作指令集,
    # defender_index：被击打着索引,
    # Firster_index：如果有回击，先攻者索引,
    # isAI=False：是否是AI调用的
    def update_unit(self, index: int, actions: list[tuple[str, int]], defender_index=-1, Firster_index=-1, isAI=False):
        # 行动入队列
        self.actions_queue.put((index, actions))
        # 更新伤害累计值
        # 更新坐标，因为只有确定要执行的动作才会放进队列中，此时就可以直接更新坐标了
        for move_action in actions:
            if move_action[0] == 'battle' and defender_index != -1:
                # 计算伤害以及扣除伤害，并将是否删除单位记录下来，放到队列中，用于在动画播放的时候延迟删除
                # Firster_index，即在有回击的情况下，先手出击的单位索引
                self.remove_queue.put(self.battle_action(self.UBlocks[index], self.UBlocks[defender_index], Firster_index))
            else:
                self.UBlocks[index].update_coordinate(move_action[1])
        # 没有正在执行的动画
        if not self.actions:
            self.index, self.actions = self.actions_queue.get()
            # 设置计时器，重新生成实例，断联原来连接的函数
            self.timer = QTimer()
            if isAI:
                self.timer.timeout.connect(lambda: self.update_unit_frame(True))
            else:
                self.timer.timeout.connect(self.update_unit_frame)
            self.timer.start(50)

    # 单位更新一帧
    def update_unit_frame(self, isAI=False):
        if self.action_unit is not None:
            unit = self.action_unit
        else:
            unit = self.UBlocks[self.index]
        unit.mode = self.actions[self.offset][0]
        complete = unit.update_animation(self.actions[self.offset][1])
        # 单位完成了一个动作
        if complete:
            # 执行下一帧动作
            self.offset += 1
        # 单位完成了所有的动作
        if self.offset == len(self.actions):
            self.action_unit = None
            # 战斗动作就要计算伤害
            if self.actions[-1][0] == 'battle':
                remove_unit = self.remove_queue.get()
                if remove_unit:
                    self.removeItem(remove_unit)
            # 动作列表空了
            if self.actions_queue.empty():
                self.index, self.actions = 0, []
                self.offset = 0
                self.timer.stop()
                # 如果是ai，则执行完所有动作之后跳到下一回合
                if isAI:
                    self.parent().update_turn()
            # 下一个动作
            else:
                self.index, self.actions = self.actions_queue.get()
                self.offset = 0
