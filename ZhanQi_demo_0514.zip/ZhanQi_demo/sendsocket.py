import socket

SERVER_HOST = '175.178.247.195'
#SERVER_HOST = 'localhost'
SERVER_PORT = 5555

username = ""
recipient = ""
faction = ""

# 创建一个TCP socket
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# 连接到服务器
client_socket.connect((SERVER_HOST, SERVER_PORT))

print("[*] Connected to server")
