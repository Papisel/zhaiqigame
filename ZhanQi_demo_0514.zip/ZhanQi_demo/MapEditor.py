import json
import os

from PySide6.QtCore import Qt, QRect
from PySide6.QtGui import QFont, QPixmap, QFontDatabase
from PySide6.QtWidgets import QPushButton, QLineEdit, QListWidget, QWidget, QLabel, QListWidgetItem, QMessageBox

import sendsocket
import Tool
from Grid import Grid

username = sendsocket.username

# 设置基本间距
left = 8
up = 8

# 设置输入框基本长宽
labelWidth = 15
labelHeight = 20

# 设置输入框基本长宽
edit1Width = 50
edit1Height = 20

# 设置按钮基本长宽
buttonWidth = 60
buttonHeight = 30


# 创建指定名字、指定大小的空白地图用于初始显示
def blank_map(name, length, width):
    data = dict()
    data["block_map"] = {"name": name, "size": [length, width], "block": []}
    data["unit_map"] = {"faction": ["red", "blue"], "unit": []}
    for y in range(width):
        data["block_map"]["block"].append(list())
        for _ in range(length):
            data["block_map"]["block"][y].append(str())
    return data


class MapEditor(QWidget):
    def __init__(self):
        super().__init__()
        # 选择地图
        self.map_path = None
        # 地形选择器
        self.list_widget_terrain = QListWidget(self)
        self.list_widget_terrain.itemClicked.connect(self.select_terrain)
        self.list_widget_terrain.setStyleSheet(
            """
            QListWidget {
                background-color: rgba(51, 51, 51, 0.6); /* 透明度0.6的深灰色背景 */
                color: rgba(255, 255, 255, 0.8); /* 白色字体，透明度0.8 */
                border: 1px solid #666; /* Medium gray */
                border-radius: 10px; /* 圆角 */
                font-weight: bold; /* 设置字体加粗 */
            }
            """
        )
        self.load_terrain()

        # 单位选择器
        self.list_widget_entity = QListWidget(self)
        self.list_widget_entity.itemClicked.connect(self.select_entity)
        self.list_widget_entity.setVisible(False)
        self.list_widget_entity.setStyleSheet(
            """
            QListWidget {
                background-color: rgba(51, 51, 51, 0.6); /* 透明度0.6的深灰色背景 */
                color: rgba(255, 255, 255, 0.8); /* 白色字体，透明度0.8 */
                border: 1px solid #666; /* Medium gray */
                border-radius: 10px; /* 圆角 */
                font-weight: bold; /* 设置字体加粗 */
            }
            """
        )
        self.load_entity()

        # 切换按钮
        self.button = QPushButton("切换", self)
        self.button.clicked.connect(self.exchange_ter_ent)
        # 展示文本
        font_family = ''
        font_path = "Asset/fonts/font1.ttf"
        font_id = QFontDatabase.addApplicationFont(font_path)
        if font_id != -1:
            font_family = QFontDatabase.applicationFontFamilies(font_id)[0]
        # 创建一个QFont对象
        font = QFont()
        font.setPointSize(14)  # 设置字体大小为14
        font.setFamily(font_family)
        self.labelHand = QLabel(self)
        self.labelHand.setFont(font)  # 设置字体
        self.labelHand.setStyleSheet("color: white;")
        self.labelHand.setText("地 图 编 辑 器")
        font1 = QFont()
        font1.setPointSize(9)  # 设置字体大小为14
        font1.setFamily(font_family)
        # 输入地图名
        self.label0 = QLabel(self)
        self.label0.setText("地图名：")
        self.label0.setFont(font1)  # 设置字体
        self.label0.setStyleSheet("color: white;")
        self.line_edit0 = QLineEdit(self)

        # 输入地图长宽
        self.label1 = QLabel(self)
        self.label1.setText("列：")
        self.label1.setFont(font1)  # 设置字体
        self.label1.setStyleSheet("color: white;")
        self.label2 = QLabel(self)
        self.label2.setText("行：")
        self.label2.setFont(font1)  # 设置字体
        self.label2.setStyleSheet("color: white;")
        self.line_edit1 = QLineEdit(self)
        self.line_edit2 = QLineEdit(self)

        # 返回
        self.button0 = QPushButton("返回", self)
        self.button0.clicked.connect(self.quit)
        # 新建地图
        self.button1 = QPushButton("新建", self)
        self.button1.clicked.connect(self.new_map)
        # 保存地图
        self.button2 = QPushButton("上传", self)
        self.button2.clicked.connect(self.save_map)
        # # 上传地图
        # self.button3 = QPushButton("上传", self)
        # self.button3.clicked.connect(self.send_map)
        # 地图视窗
        self.viewer = Grid(self)
        self.viewer.editor_mode = True
        # 当前选择的
        self.selected_terrain = ''
        self.selected_entity = ''
        # # 创建一个QFont对象
        # font = QFont()
        # font.setPointSize(14)  # 设置字体大小为14
        # font.setFamily(font_family)
        #
        # self.labelHand = QLabel(self)
        # self.labelHand.setFont(font)  # 设置字体
        # self.labelHand.setStyleSheet("color: white;")
        # self.labelHand.setText("地 图 编 辑 器")
        #
        # # 输入地图名
        # self.label0 = QLabel(self)
        # self.label0.setStyleSheet("color: white;")
        # self.label0.setText("地图名：")
        #
        # self.line_edit0 = QLineEdit(self)
        #
        # # 输入地图长宽
        # self.label1 = QLabel(self)
        # self.label1.setStyleSheet("color: white;")
        # self.label1.setText("列：")
        #
        # self.label2 = QLabel(self)
        # self.label2.setStyleSheet("color: white;")
        # self.label2.setText("行：")
        #
        # self.line_edit1 = QLineEdit(self)
        # self.line_edit2 = QLineEdit(self)
        #
        # # 返回
        # self.button0 = QPushButton("返回", self)
        # self.button0.clicked.connect(self.quit)
        # # 新建地图
        # self.button1 = QPushButton("新建", self)
        # self.button1.clicked.connect(self.new_map)
        # # 保存地图
        # self.button2 = QPushButton("上传", self)
        # self.button2.clicked.connect(self.save_map)
        # # # 上传地图
        # # self.button3 = QPushButton("上传", self)
        # # self.button3.clicked.connect(self.send_map)
        # # 地图视窗
        # self.viewer = Grid(self)
        # self.viewer.editor_mode = True
        # # 当前选择的
        # self.selected_terrain = ''
        # self.selected_entity = ''
        # self.setStyleSheet(
        #     f"""
        #           QMainWindow {{
        #               background-image: url('Asset/UI/bg1.jpg');
        #               background-repeat: no-repeat;
        #               background-position: center center; /* Place the background image in the center of the window */
        #               background-color: #000000; /* Set the background color to black */
        #               background-size: cover; /* Adjust the background image to cover the entire window */
        #           }}
        #           QPushButton {{
        #               font-weight: bold; /* 设置字体加粗 */
        #               font-family: "{font}"; /* 使用Python变量 */
        #               background-color: rgba(0, 0, 0, 0.6); /* 设置按钮背景色为黑色，透明度为0.6 */
        #               border-radius: 15px; /* 设置按钮圆角边框 */
        #               color: rgba(255, 255, 255, 1.0); /* 设置字体颜色为白色，透明度为0.5 */
        #           }}
        #           QPushButton:hover {{
        #               background-color: rgba(0, 0, 0, 0.8); /* 设置鼠标悬停时按钮背景色透明度变低 */
        #           }}
        #           QLineEdit {{
        #               font-weight: bold; /* 设置字体加粗 */
        #               font-family: "{font}"; /* 使用Python变量 */
        #               border-radius: 15px; /* 设置圆角边框 */
        #               background-color: rgba(0, 0, 0, 0.6); /* 设置输入框背景色为黑，透明度为0.6 */
        #               padding: 6px; /* 设置字体与边框之间的间距为6像素 */
        #               color: rgba(255, 255, 255, 1.0); /* 设置字体颜色为白色，透明度为0.5 */
        #           }}
        #           QLineEdit:hover {{
        #               background-color: rgba(0, 0, 0, 0.8); /* 设置鼠标悬停时按钮背景色透明度变低 */
        #           }}
        #           """
        # )


    def map(self):
        if self.map_path:
            # 打开 JSON 文件
            basic = Tool.load_json(self.map_path)
            block = basic["block_map"]
            mapName = block["name"]
            length, width = str(block["size"][0]), str(block["size"][1])
            self.line_edit0.setText(mapName)
            self.line_edit1.setText(length)
            self.line_edit2.setText(width)
            map = basic
            self.viewer.load_map(map)

    # 布局
    def resizeEvent(self, event) -> None:
        w, h = self.width(), self.height()

        widgetWidth = 224
        widgetHeight = h - 200

        viewWidth = w - widgetWidth - left * 3
        viewHeight = h - up * 2

        AllUp = up
        AllLeft = left
        # 左上角坐标（x,y），宽，高
        # 切换按钮
        self.button.setGeometry(left, AllUp, buttonWidth, buttonHeight)

        self.labelHand.setGeometry(buttonWidth + left * 3, up * 2, labelWidth * 10, labelHeight)

        # 块/单位 选择框
        AllUp += buttonHeight
        self.list_widget_terrain.setGeometry(left, up + AllUp, widgetWidth, widgetHeight)
        self.list_widget_entity.setGeometry(left, up + AllUp, widgetWidth, widgetHeight)

        # 地图名输入框
        AllUp += widgetHeight + up
        self.label0.setGeometry(AllLeft, up + AllUp, labelWidth * 3, labelHeight)
        AllLeft += labelWidth * 3
        self.line_edit0.setGeometry(AllLeft + left, up + AllUp, edit1Width * 2, edit1Height)

        # 长宽输入框
        AllLeft = left
        AllUp += edit1Height + up
        self.label1.setGeometry(AllLeft + left, up + AllUp, labelWidth, labelHeight)
        AllLeft += labelWidth + left * 4.6
        self.line_edit1.setGeometry(AllLeft, up + AllUp, edit1Width, edit1Height)
        AllLeft = left
        AllUp += edit1Height + up
        self.label2.setGeometry(AllLeft + left, up + AllUp, labelWidth, labelHeight)
        AllLeft += labelWidth + left * 4.6
        self.line_edit2.setGeometry(AllLeft, up + AllUp, edit1Width, edit1Height)

        # 新建地图按钮
        AllUp += edit1Height + up * 2
        AllLeft = left
        self.button1.setGeometry(left, AllUp + up, buttonWidth, buttonHeight)

        # 保存地图按钮
        AllLeft += buttonWidth + left * 2
        self.button2.setGeometry(AllLeft, AllUp + up, buttonWidth, buttonHeight)

        # 返回按钮
        AllLeft += buttonWidth + left * 2
        self.button0.setGeometry(AllLeft, AllUp + up, buttonWidth, buttonHeight)

        AllLeft = widgetWidth + left
        AllUp = up
        self.viewer.setGeometry(AllLeft + left, AllUp, viewWidth, viewHeight)

    # 切换是布局块还是布局单位
    def exchange_ter_ent(self):
        self.list_widget_terrain.setVisible(not self.list_widget_terrain.isVisible())
        self.list_widget_entity.setVisible(not self.list_widget_entity.isVisible())

    # 导入文件夹全部地形
    def load_terrain(self):
        path = Tool.where() + "/Asset/Terrain"
        fs = Tool.get_all(path)
        for f in fs:
            item = Item(f)
            list_item = QListWidgetItem()
            list_item.setSizeHint(item.size())
            self.list_widget_terrain.addItem(list_item)
            self.list_widget_terrain.setItemWidget(list_item, item)

    def load_entity(self):
        def load_items(path, color):
            fs = Tool.get_all(path)
            for f in fs:
                if "battle" in f:
                    continue
                item = Item(f)
                list_item = QListWidgetItem()
                list_item.setSizeHint(item.size())
                self.list_widget_entity.addItem(list_item)
                self.list_widget_entity.setItemWidget(list_item, item)

        path_blue = Tool.where() + "/Asset/Entity/blue"
        path_red = Tool.where() + "/Asset/Entity/red"

        load_items(path_blue, "Blue")
        load_items(path_red, "Red")

    def select_terrain(self):
        selected_items = self.list_widget_terrain.selectedItems()
        if selected_items:
            item = self.list_widget_terrain.itemWidget(selected_items[0])
            self.selected_terrain = item.name
            self.selected_entity = ''

    def select_entity(self):
        selected_items = self.list_widget_entity.selectedItems()
        if selected_items:
            item = self.list_widget_entity.itemWidget(selected_items[0])
            self.selected_terrain = ''
            self.selected_entity = item.name

    # 退出地图编辑器
    def quit(self):
        self.line_edit0.clear()
        self.line_edit1.clear()
        self.line_edit2.clear()
        self.window().home()

    # 新建地图
    # def new_map(self):
    #     mapName = self.line_edit0.text()
    #     length = self.line_edit1.text()
    #     width = self.line_edit2.text()
    #     # 检查length和width是否都是整型数字
    #     if mapName and length.isdigit() and width.isdigit():
    #         map = blank_map(mapName, int(length), int(width))
    #         self.viewer.load_map(map)
    #
    # # 保存地图
    # def save_map(self):
    #     mapName = self.line_edit0.text()
    #     length = self.line_edit1.text()
    #     width = self.line_edit2.text()
    #     # 检查length和width是否都是整型数字
    #     if mapName and length.isdigit() and width.isdigit():
    #         map = blank_map(mapName, int(length), int(width))
    #         self.viewer.save_map(map)
    #         self.window().page4.load_map()
    #         self.send_map(mapName)

    def new_map(self):
        mapName = self.line_edit0.text()
        length = self.line_edit1.text()
        width = self.line_edit2.text()
        # 检查是否输入了完整信息
        if not mapName or not length or not width:
            QMessageBox.warning(self, "警告", "请输入完整地图创建信息", QMessageBox.Ok)
            return
        # 检查length和width是否都是整型数字
        if mapName and length.isdigit() and width.isdigit():
            map = blank_map(mapName, int(length), int(width))
            self.viewer.load_map(map)

        # 保存地图

    def save_map(self):
        mapName = self.line_edit0.text()
        length = self.line_edit1.text()
        width = self.line_edit2.text()
        # 检查是否输入了完整信息
        if not mapName or not length or not width:
            QMessageBox.warning(self, "警告", "输入不能置空", QMessageBox.Ok)
            return
        # 检查length和width是否都是整型数字
        if mapName and length.isdigit() and width.isdigit():
            map = blank_map(mapName, int(length), int(width))
            res = self.viewer.save_map(map)
            if not res:
                QMessageBox.warning(self, "警告", "地图未创建", QMessageBox.Ok)
            self.window().page4.load_map()
            self.send_map(mapName)

    def send_map(self, mapName):
        # 读取本地 JSON 文件
        # filename = "temp/%s.json", mapName
        #filename = f"map/{mapName}.json"
        filename = f"map/{mapName}.json"
        if not os.path.exists(filename):
            return
        else:
            with open(filename, 'r') as file:
                  json_data = json.load(file)
        #json_data = self.read_json_file(filename)
        # 准备要发送的数据
        file_info = {
            'action': 'send_map',
            'mapname': mapName,
            'username': sendsocket.username,
            'data': json_data
        }
        # 发送数据
        # sendsocket.client_socket.send(json.dumps(file_info).encode('utf-8'))
        # 将数据转换为 JSON 格式的字符串
        json_string = json.dumps(file_info)
        # 将 JSON 字符串转换为字节对象
        byte_data = json_string.encode('utf-8')

        # 发送字节数据给 socket 连接
        sendsocket.client_socket.send(byte_data)

    # 读取本地 JSON 文件
    # def read_json_file(self, filename):
    #     with open(filename, 'r') as file:
    #         data = json.load(file)
    #     return data
    # def read_json_file(self, filename):
    #     if not os.path.exists(filename):
    #         pass
    #         return None
    #
    #     with open(filename, 'r') as file:
    #         data = json.load(file)
    #     return data


# 块选择框类
class Item(QWidget):
    def __init__(self, path):
        super().__init__()
        # 路径
        self.path = path
        if "red" in path.split('/')[-2]:
            self.name = "red_" + path.split('/')[-1].split('_')[0]
        elif "blue" in path.split('/')[-2]:
            self.name = "blue_" + path.split('/')[-1].split('_')[0]
        else:
            self.name = path.split('/')[-1].split('.')[0]
        # 框架
        self.label1 = self.terrain_label(path)
        self.label2 = self.name_label()
        # 几何
        self.set_size(224, 70)

    def terrain_label(self, path):
        label = QLabel(self)
        if "Entity" not in path:
            icon = QPixmap(path)
            label.setPixmap(icon)
        else:
            icon = QPixmap(path)
            o_w, o_h = icon.width(), icon.height()
            s_w = o_w // 4
            s_h = o_h // 4
            pixmap_rect = QRect(0, 0, s_w, s_h)
            pixmap = icon.copy(pixmap_rect)
            label.setPixmap(pixmap)
        # label.setScaledContents(True)
        return label

    def name_label(self):
        label = QLabel(self)
        label.setText(self.name)
        font = QFont()
        font.setPixelSize(12)
        label.setFont(font)
        label.setAlignment(Qt.AlignCenter)
        return label

    def set_size(self, w, h):
        self.resize(w, h)
        h -= 6
        self.label1.setGeometry(0, 3, h, h)
        self.label2.setGeometry(h, 3, w - h, h)
