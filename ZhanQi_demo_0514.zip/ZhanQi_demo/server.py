import socket
import threading
import mysql.connector
import json

# 定义服务器地址和端口
SERVER_HOST = '127.0.0.1'
SERVER_PORT = 5555

# MySQL数据库连接配置
DB_HOST = 'localhost'
DB_USER = 'root'
DB_PASSWORD = '187294361'  # 修改为你的数据库密码
DB_DATABASE = 'zhanqigame'

# 创建数据库连接
db_connection = mysql.connector.connect(
    host=DB_HOST,
    user=DB_USER,
    password=DB_PASSWORD,
    database=DB_DATABASE,
    buffered=True
)

# 创建游标对象
db_cursor = db_connection.cursor()

# 创建一个TCP socket
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# 绑定服务器地址和端口
server_socket.bind((SERVER_HOST, SERVER_PORT))

# 开始监听连接
server_socket.listen(5)

print(f"[*] Listening on {SERVER_HOST}:{SERVER_PORT}")

# 存储客户端socket和用户名的字典
client_sockets = {}
usernames = {}
online_users = {}





def handle_client(client_socket, client_address):
    print(f"[*] Accepted connection from {client_address}")
    try:
        while True:
            # 接收客户端发送的数据
            data = client_socket.recv(4096).decode('utf-8')
            # 解析收到的数据
            file_info = json.loads(data)

            if not data:
                break

            # # 解析收到的数据
            # request = data.split('|')
            # action = request
            action = file_info['action']

            # 处理登录请求
            if action == 'login':
                username = file_info['username']
                password = file_info['password']

                # 查询数据库验证用户信息
                select_query = "SELECT * FROM users WHERE username = %s AND password = %s"
                db_cursor.execute(select_query, (username, password))
                user = db_cursor.fetchone()

                # 发送登录结果给客户端
                if user:
                    response = 'Login success'
                    client_sockets[username] = client_socket  # 将客户端socket存储到字典中
                    usernames[client_socket] = username  # 将用户名与客户端socket关联起来
                    # 设置用户状态为1（已登录）
                    update_query = "UPDATE users SET status = 1 WHERE username = %s"
                    db_cursor.execute(update_query, (username,))
                    db_connection.commit()
                    online_users[username] = client_socket
                    update_user_status(username, 1)  # 设置用户状态为在线
                    # send_online_users()
                    # db_cursor.fetchall()  # 读取结果，避免未读取结果的错误
                else:
                    response = 'Login failed'

                # 准备要发送的数据
                file_info = {
                    'action': 'login',
                    'response': response,
                }
                # 发送数据
                client_socket.send(json.dumps(file_info).encode('utf-8'))

            # 处理注册请求
            elif action == 'register':
                username = file_info['username']
                password = file_info['password']

                # 检查用户名是否已存在
                select_query = "SELECT * FROM users WHERE username = %s"
                db_cursor.execute(select_query, (username,))
                existing_user = db_cursor.fetchone()

                # 如果用户名不存在，将新用户信息插入数据库
                if not existing_user:
                    # 执行SQL查询
                    sql = "SELECT COUNT(*) FROM users"
                    db_cursor.execute(sql)

                    # 获取结果
                    result = db_cursor.fetchone()
                    total_users = result[0]
                    insert_query = "INSERT INTO users (ID,username, password,rank,fight1,fight2,win,status) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)"
                    db_cursor.execute(insert_query, (total_users, username, password, total_users, 0, 0, 0, 0))
                    db_connection.commit()
                    response = 'Register success'
                else:
                    response = 'Username already exists'

                # 准备要发送的数据
                file_info = {
                    'action': 'register',
                    'response': response
                }
                # 发送数据
                client_socket.send(json.dumps(file_info).encode('utf-8'))

                # 处理获取在线用户列表请求
            elif action == 'get_online_users':
                username = file_info['username']
                print(username)
                send_online_users(username)

            elif action == 'get_maps':
                username = file_info['username']
                #print(username)
                send_maps(username)

            # 处理发送消息请求
            elif action == 'send_message':
                sender_username = usernames[client_socket]
                recipient_username = file_info['recipient']
                message = file_info['message']

                if recipient_username in client_sockets:
                    recipient_socket = client_sockets[recipient_username]
                    message = f'Message from{sender_username}: {message}'
                    # 准备要发送的数据
                    file_info = {
                        'action': 'info',
                        'message': message,
                    }
                    # 发送数据
                    recipient_socket.send(json.dumps(file_info).encode('utf-8'))
                    # recipient_socket.sendall(f'info|Message from {sender_username}: {message}'.encode())

                # 处理发送消息请求
            elif action == 'game_invitation':
                sender_username = usernames[client_socket]
                mapName = file_info['mapname']
                recipient_username = file_info['recipient']
                #message = file_info['message']

                if recipient_username in client_sockets:
                    recipient_socket = client_sockets[recipient_username]
                    #message = f'Message from{sender_username}: {message}'
                    # 准备要发送的数据
                    file_info = {
                        'action': 'gameinvitation',
                        'mapName': mapName,
                        'recipient': sender_username,
                    }
                    # 发送数据
                    recipient_socket.send(json.dumps(file_info).encode('utf-8'))

                # 处理发送消息请求
            elif action == 'invitationrece':
                sender_username = usernames[client_socket]
                recipient_username = file_info['recipient']
                mapName = file_info['mapname']
                response = file_info['response']

                if recipient_username in client_sockets:
                    recipient_socket = client_sockets[recipient_username]
                    # message = f'Message from{sender_username}: {message}'
                    # 准备要发送的数据
                    file_info = {
                        'action': 'invitationrece',
                        'recipient': sender_username,
                        'mapName': mapName,
                        "response": response,
                    }
                    # 发送数据
                    recipient_socket.send(json.dumps(file_info).encode('utf-8'))

            elif action == 'gameturn':
                sender_username = usernames[client_socket]
                recipient_username = file_info['recipient']
                response = file_info['response']
                # message = file_info['message']

                if recipient_username in client_sockets:
                    recipient_socket = client_sockets[recipient_username]
                    # message = f'Message from{sender_username}: {message}'
                    # 准备要发送的数据
                    file_info = {
                        'action': 'gameturn',
                        'response': response
                    }
                    # 发送数据
                    recipient_socket.send(json.dumps(file_info).encode('utf-8'))

            elif action == 'battle':
                sender_username = usernames[client_socket]
                recipient_username = file_info['recipient']
                response = file_info['response']
                # message = file_info['message']

                if recipient_username in client_sockets:
                    recipient_socket = client_sockets[recipient_username]
                    # message = f'Message from{sender_username}: {message}'
                    # 准备要发送的数据
                    file_info = {
                        'action': 'battle',
                        'response': response
                    }
                    # 发送数据
                    recipient_socket.send(json.dumps(file_info).encode('utf-8'))

            # 处理获取JSON文件请求
            elif action == 'getmap':
                username = file_info['username']
                mapName = file_info['mapname']

                # 检查该用户是否在线
                if username in online_users:
                    socket = online_users[username]

                try:
                    db_connection.commit()
                    select_query = "SELECT data FROM maps WHERE name = %s"
                    db_cursor.execute(select_query,(mapName,))
                    data = db_cursor.fetchone()
                    if data:
                        data_string = data[0]  # 从数据库中读取字符串型的JSON
                    else:
                        # 数据库中没有找到对应的地图数据
                        data_string = 'Map not found'
                except Exception as e:
                    # 数据库查询失败
                    print("Database error:", e)
                    data_string = 'Database error'

                # 准备要发送的数据
                file_info = {
                    'action': 'getmap',
                    'mapname': mapName,
                    'response': data_string
                }
                # 发送数据
                socket.send(json.dumps(file_info).encode('utf-8'))

            elif action == 'send_map':
                name = file_info['mapname']
                username = file_info['username']
                data = file_info['data']

                # 检查该用户是否在线
                if username in online_users:
                    socket = online_users[username]

                # 检查用户名是否已存在
                select_query = "SELECT * FROM maps WHERE name = %s"
                db_cursor.execute(select_query, (name,))
                existing_map = db_cursor.fetchone()

                # 如果用户名不存在，将新用户信息插入数据库
                if not existing_map:
                    # # 执行SQL查询
                    # sql = "SELECT COUNT(*) FROM maps"
                    # db_cursor.execute(sql)
                    #
                    # # 获取结果
                    # result = db_cursor.fetchone()
                    # total_users = result[0]
                    # insert_query = "INSERT INTO users (ID,username, password,rank,fight1,fight2,win,status) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)"
                    # db_cursor.execute(insert_query, (total_users, username, password, total_users, 0, 0, 0, 0))
                    # db_connection.commit()

                    # 查询用户ID
                    username = file_info['username']
                    select_user_query = "SELECT ID FROM users WHERE username = %s"
                    db_cursor.execute(select_user_query, (username,))
                    user_result = db_cursor.fetchone()

                    if user_result:
                        user_id = user_result[0]
                    else:
                        print(f"User {username} not found")
                        continue  # 如果用户不存在，则跳过保存文件的步骤

                    # 执行SQL查询获取地图数量
                    sql = "SELECT COUNT(*) FROM maps"
                    db_cursor.execute(sql)
                    result = db_cursor.fetchone()
                    total_maps = result[0]

                    # 将文件信息保存到数据库
                    query = "INSERT INTO maps (map, name, ID, data) VALUES (%s, %s, %s, %s)"
                    values = (total_maps, file_info['mapname'], user_id, json.dumps(data))
                    # values = (total_maps, file_info['mapname'], user_id, json.dumps(''))
                    db_cursor.execute(query, values)
                    db_connection.commit()
                    response = 'File received successfully'
                else:
                    response = 'Mapname already exists'

                # 准备要发送的数据
                file_info = {
                    'action': 'send_map',
                    'response': response
                }
                # 发送数据
                socket.send(json.dumps(file_info).encode('utf-8'))


            elif action == 'logout':
                username = file_info['username']
                # 设置用户状态为0（已退出）
                update_query = "UPDATE users SET status = 0 WHERE username = %s"
                db_cursor.execute(update_query, (username,))
                db_connection.commit()
                if username in online_users:
                    del online_users[username]

    except ConnectionResetError:
        # 处理远程主机强制关闭连接的情况
        print("ConnectionResetError occurred. Updating user status to 0.")
        # 更新用户状态为 0，例如：
        if client_socket in usernames:
            username = usernames[client_socket]
            update_query = "UPDATE users SET status = 0 WHERE username = %s"
            db_cursor.execute(update_query, (username,))
            db_connection.commit()
            del client_sockets[username]
            del usernames[client_socket]
            print(f"[*] User {username} disconnected and status set to 0")
            print(f"[*] Connection from {client_address} closed")
    finally:
        client_socket.close()
    # 当客户端断开连接时，更新数据库中对应用户的状态为0

def send_maps(username):
    maps = get_maps()
    print(maps)
    # 检查该用户是否在线
    if username in online_users:
        socket = online_users[username]
        # 准备要发送的数据
        file_info = {
            'action': 'map',
            'response': maps
        }
        # 发送数据
        socket.send(json.dumps(file_info).encode('utf-8'))
        # socket.sendall(f"online|{online_usernames}".encode('utf-8'))
    else:
        print(f"User '{username}' is not online.")

def get_maps():
    db_connection.commit()
    select_query = "SELECT name FROM maps"
    db_cursor.execute(select_query)
    maps = db_cursor.fetchall()
    #online_users=db_cursor.fetchall()
    result = ",".join([map[0] for map in maps])
    # result = "|".join([f"{row[0]}-{row[1]}" for row in maps_names])
    # print(result)
    return result


def send_online_users(username):
    online_usernames = get_online_usernames()
    # 检查该用户是否在线
    if username in online_users:
        socket = online_users[username]
        # 准备要发送的数据
        file_info = {
            'action': 'online',
            'response': online_usernames
        }
        # 发送数据
        socket.send(json.dumps(file_info).encode('utf-8'))
        #socket.sendall(f"online|{online_usernames}".encode('utf-8'))
    else:
        print(f"User '{username}' is not online.")


# 从数据库中获取在线用户列表
def get_online_usernames():
    db_connection.commit()
    select_query = "SELECT username FROM users WHERE status = 1"
    db_cursor.execute(select_query)
    online_users = db_cursor.fetchall()
    result = ",".join([user[0] for user in online_users])
    return result


# 更新用户状态
def update_user_status(username, status):
    update_query = "UPDATE users SET status = %s WHERE username = %s"
    db_cursor.execute(update_query, (status, username))
    db_connection.commit()


# 循环接受客户端连接
while True:
    # 等待客户端连接
    client_socket, client_address = server_socket.accept()

    # 创建一个线程来处理客户端请求
    client_thread = threading.Thread(target=handle_client, args=(client_socket, client_address))
    client_thread.start()
