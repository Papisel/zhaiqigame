from PySide6.QtCore import Qt
from PySide6.QtGui import QPixmap, QFont, QFontDatabase
from PySide6.QtWidgets import QWidget, QLabel, QPushButton

pixWidth = 70
pixHeight = 70

textWidth = 150
textHeight = 23

left = 10
up = 10
add = 6


class Hint(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        # 展示图片
        self.label_pix = QLabel(self)
        self.label_pix.setStyleSheet("border: 2px solid #ffffff; background-color: gray")
        # 展示文本
        font_family = ''
        font_path = "Asset/fonts/font1.ttf"
        font_id = QFontDatabase.addApplicationFont(font_path)
        if font_id != -1:
            font_family = QFontDatabase.applicationFontFamilies(font_id)[0]
        # 创建一个QFont对象
        font = QFont()
        font.setPointSize(11)  # 设置字体大小为11
        font.setFamily(font_family)
        bigFont = QFont()
        bigFont.setPointSize(15)  # 设置字体大小为11
        bigFont.setFamily(font_family)
        self.label_location = QLabel(self)
        self.label_location.setFont(font)  # 设置字体
        self.label_name = QLabel(self)
        self.label_name.setFont(font)  # 设置字体
        # 块特有
        self.label_access = QLabel(self)
        self.label_access.setFont(font)  # 设置字体
        # 单位特有
        self.label_health = QLabel(self)
        self.label_health.setFont(font)  # 设置字体
        self.label_attack = QLabel(self)
        self.label_attack.setFont(font)  # 设置字体
        self.label_move = QLabel(self)
        self.label_move.setFont(font)  # 设置字体
        self.label_moveType = QLabel(self)
        self.label_moveType.setFont(font)  # 设置字体
        self.label_ready = QLabel(self)
        self.label_ready.setFont(bigFont)  # 设置字体
        # 退出游戏与下一回合
        self.label_turn = QLabel(self)
        self.label_turn.setFont(bigFont)  # 设置字体
        self.button1 = QPushButton("下一回合", self)
        self.button1.clicked.connect(self.next_turn)
        self.button2 = QPushButton("退出", self)
        self.button2.clicked.connect(self.quit_game)

    def put_faction(self):
        # 获取到阵营颜色
        faction = self.parent().faction

    # 一个格子被点击
    def display_block(self, item):
        self.clear()
        pixmap = item.terrain_item.pixmap()
        pixmap = pixmap.scaled(pixWidth, pixHeight, Qt.KeepAspectRatio)  # 将图片缩放到和方格一样的大小
        size = pixmap.size()
        self.label_pix.resize(size)
        self.label_pix.setPixmap(pixmap)
        #
        self.label_location.setText("坐标： " + str(item.coordinate))
        #
        self.label_name.setText("地形： " + item.get_stats()["name"])
        #
        _type = item.get_stats()["type"]
        access = ""
        match _type:
            case 0:
                access = " 🚫 "
            case 1:
                access = "🚢🚁"
            case 2:
                access = "🚗🚁"
            case 3:
                access = " 🚁 "
        self.label_access.setText("通行： " + access)

    # 一个单位被点击
    def display_unit(self, item):
        self.clear()
        pixmap = item.unit_item.pixmap()
        pixmap = pixmap.scaled(pixWidth, pixHeight * 2, Qt.KeepAspectRatio)  # 将图片缩放到和方格一样的大小
        size = pixmap.size()
        self.label_pix.resize(size)
        # 图片
        self.label_pix.setPixmap(pixmap)
        # 坐标
        self.label_location.setText("坐标： " + str(item.coordinate))
        # 单位
        self.label_name.setText("单位： " + item.get_cur_stats()["name"])
        # 生命值
        self.label_health.setText("HP ：" + str(item.get_cur_stats()["health"]))
        # 攻击力
        self.label_attack.setText("ATK：" + str(item.get_cur_stats()["attack"]))
        # 移动距离
        self.label_move.setText("MOV：" + str(item.get_cur_stats()["move"]))
        # 移动类型
        _type = item.get_cur_stats()["move_type"]
        moveType = ""
        match _type:
            case 1:
                moveType = "🚢"
            case 2:
                moveType = "🚗"
            case 3:
                moveType = "🚁"
        self.label_moveType.setText("类型： " + moveType)
        # 是否可行动
        ready = "✅" if item.ready else "❌"
        self.label_ready.setText(ready)

    def display_turn(self, faction, your_turn):
        if faction == 'red':
            turn = '🔶' if your_turn else '🔷'
        else:
            turn = '🔷' if your_turn else '🔶'  # 假设只有'red'和另一个阵营
        self.label_turn.setText(f"当前回合阵营: {turn}")

    # 下一回合
    def next_turn(self):
        self.parent().next_turn()

    # 退出
    def quit_game(self):
        # 清理界面
        pixmap = QPixmap()
        self.label_pix.setPixmap(pixmap)
        self.clear()
        # 退出到主页面
        self.parent().quit_game()

    def clear(self):
        self.label_location.setText("")
        self.label_name.setText("")
        self.label_access.setText("")
        self.label_health.setText("")
        self.label_attack.setText("")
        self.label_move.setText("")
        self.label_moveType.setText("")
        self.label_ready.setText("")

    # 设置各部件位置
    def resizeEvent(self, event) -> None:
        w, h = self.width(), self.height()
        # 图片框
        self.label_pix.setGeometry(left, up, pixWidth, pixHeight)
        # 文字表示
        self.label_location.setGeometry(left + pixWidth + add, up, textWidth, textHeight)
        self.label_name.setGeometry(left + pixWidth + add, up + textHeight, textWidth, textHeight)
        # 块特有
        self.label_access.setGeometry(left + pixWidth + add, up + textHeight * 2, textWidth, textHeight)
        # 单位特有
        self.label_health.setGeometry(left + pixWidth + add, up + textHeight * 2, textWidth, textHeight)
        self.label_attack.setGeometry(left + pixWidth + add, up + textHeight * 3, textWidth, textHeight)
        self.label_move.setGeometry(left + pixWidth + add, up + textHeight * 4, textWidth, textHeight)
        self.label_moveType.setGeometry(left + pixWidth + add, up + textHeight * 5, textWidth, textHeight)
        self.label_ready.setGeometry(left + pixWidth * 2 + add * 5, up + textHeight * 3, textWidth, textHeight * 2)
        self.label_turn.setGeometry(left, up + textHeight * 6, textWidth * 2, textHeight * 2)
        # 按钮
        self.button1.setGeometry(10, h - 140, w - 20, 40)
        self.button2.setGeometry(10, h - 90, 50, 30)
