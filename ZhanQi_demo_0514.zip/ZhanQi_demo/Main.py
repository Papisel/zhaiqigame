import json
import os
import re

from PySide6.QtGui import QFont, QIcon, QFontDatabase
from PySide6.QtWidgets import QVBoxLayout, QMessageBox, QApplication, QMainWindow, QLabel, QPushButton, QStackedWidget, \
    QWidget, QLineEdit, QTextEdit, QListWidget, QListWidgetItem
from PySide6.QtCore import Qt, Signal, QObject, QThread
import Tool
from Grid import Grid
from MapEditor import MapEditor
import sendsocket

username = ""

# hud>ui>effect>entity>map

textWidth = 100
textHeight = 50
buttonWidth = 200
buttonHeight = 50
widgetWidth = 160
widgetHeight = 200
itemWidth = 138
itemHeight = 70


class MessageReceiverThread(QThread):
    message_received = Signal(str)
    login_received = Signal(str)
    register_received = Signal(str)
    send_map_received = Signal(str)
    get_map_received = Signal(str)
    online_users_updated = Signal(str)
    win_or_lose = Signal(str)
    game = Signal(str)
    game_invitation = Signal(str)
    invitation_rece = Signal(str, str)
    map = Signal(str)
    # 战斗通讯
    update_battle = Signal(str)
    # 到我的回合了
    game_turn = Signal(str)

    def __init__(self):
        super().__init__()


    def run(self):
        while True:
            message = sendsocket.client_socket.recv(4096).decode('utf-8')
            # 解析收到的数据
            file_rece = json.loads(message)

            if not message:
                break
            # request = message.split('|')
            action = file_rece['action']

            if action == 'login':
                response = file_rece['response']
                self.login_received.emit(response)

            elif action == 'register':
                response = file_rece['response']
                self.register_received.emit(response)

            elif action == 'online':
                response = file_rece['response']
                self.online_users_updated.emit(response)

            elif action == 'map':
                response = file_rece['response']
                self.map.emit(response)

            elif action == 'info':
                response = file_rece['message']
                self.message_received.emit(response)

            elif action == 'invitationrece':
                mapname = file_rece['mapName']
                response = file_rece['response']
                self.invitation_rece.emit(mapname,response)

            elif action == 'gameinvitation':
                mapname = file_rece['mapName']
                sendsocket.recipient = file_rece['recipient']
                self.game_invitation.emit(mapname)

            elif action == 'game':
                response = file_rece['response']
                self.game.emit(response)

            elif action == 'winorlose':
                response = file_rece['response']
                self.win_or_lose.emit(response)

            elif action == 'send_map':
                response = file_rece['response']
                self.send_map_received.emit(response)

            elif action == 'getmap':
                mapname = file_rece['mapname']
                response = file_rece['response']
                try:
                    # 解析 JSON 数据
                    json_data = json.loads(response)

                    # 将接收到的数据保存为文件
                    map_path = f"map/{mapname}.json"
                    with open(map_path, 'w') as f:
                        json.dump(json_data, f)

                    self.get_map_received.emit(map_path)
                except Exception as e:
                    print("Error:", e)

            # 对方行动接受
            elif action == 'battle':
                response = file_rece['response']
                self.update_battle.emit(response)
            # 对方的回合已结束
            elif action == 'gameturn':
                response = file_rece['response']
                self.game_turn.emit(response)


class MessageSignalHandler(QObject):
    message_received = Signal(str)
    online_users_updated = Signal(str)

    def __init__(self):
        super().__init__()

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        # self.Cusername = None
        self.setWindowTitle("战棋")
        self.exe_path = Tool.where()
        self.stacked = QStackedWidget()
        self.setCentralWidget(self.stacked)
        self.resize(1280, 720)
        self.setMinimumSize(640, 480)

        self.page1 = LoginPage(parent=self, stacked=self.stacked)
        self.stacked.addWidget(self.page1)

        self.home_page = HomePage(parent=self)
        self.stacked.addWidget(self.home_page)

        self.page2 = Grid()
        self.stacked.addWidget(self.page2)

        self.page3 = MapEditor()
        self.stacked.addWidget(self.page3)

        self.page4 = MultiplayerPage(parent=self)
        self.stacked.addWidget(self.page4)

        self.page5 = AIBattlePage(parent=self)
        self.stacked.addWidget(self.page5)

        self.page_index = {
            "login_page": 0,
            "home_page": 1,
            "battle_field_page": 2,
            "map_editor_page": 3,
            "multiplayer_page": 4,
            "ai_battle_page": 5,
        }

        font = ''
        # 加载字体
        font_path = "Asset/fonts/font1.ttf"
        font_id = QFontDatabase.addApplicationFont(font_path)
        if font_id != -1:
            font_family = QFontDatabase.applicationFontFamilies(font_id)[0]
            font = font_family
        self.setStyleSheet(
            "background-color: rgba(51, 51, 51, 0.6);color: rgba(255, 255, 255, 0.8); /* 白色字体，透明度0.8 */")
        # 设置背景图片
        self.setStyleSheet(
            f"""
           QMainWindow {{
               background-image: url('Asset/UI/bg1.jpg');
               background-repeat: no-repeat;
               background-position: center center; /* Place the background image in the center of the window */
               background-color: #000000; /* Set the background color to black */
               background-size: cover; /* Adjust the background image to cover the entire window */
           }}
           QPushButton {{
               font-weight: bold; /* 设置字体加粗 */
               font-family: "{font}"; /* 使用Python变量 */
               background-color: rgba(0, 0, 0, 0.6); /* 设置按钮背景色为黑色，透明度为0.6 */
               border-radius: 15px; /* 设置按钮圆角边框 */
               color: rgba(255, 255, 255, 1.0); /* 设置字体颜色为白色，透明度为0.5 */
           }}
           QPushButton:hover {{
               background-color: rgba(0, 0, 0, 0.8); /* 设置鼠标悬停时按钮背景色透明度变低 */
           }}
           QLineEdit {{
               font-weight: bold; /* 设置字体加粗 */
               font-family: "{font}"; /* 使用Python变量 */
               border-radius: 15px; /* 设置圆角边框 */
               background-color: rgba(0, 0, 0, 0.6); /* 设置输入框背景色为黑，透明度为0.6 */
               padding: 6px; /* 设置字体与边框之间的间距为6像素 */
               color: rgba(255, 255, 255, 1.0); /* 设置字体颜色为白色，透明度为0.5 */
           }}
           QLineEdit:hover {{
               background-color: rgba(0, 0, 0, 0.8); /* 设置鼠标悬停时按钮背景色透明度变低 */
           }}
           QMessageBox {{
               background-color: rgba(99, 99, 99, 0.8); /* 设置背景色为黑色，透明度为0.8 */
               font-weight: bold; /* 设置字体加粗 */
               font-family: "{font}"; /* 使用Python变量设置字体 */
               color: rgba(0, 0, 0, 1.0); /* 设置字体颜色为白色，透明度为0.8 */
          }}
           """
        )

        self.stacked.setCurrentIndex(self.page_index["login_page"])

        self.receive_thread = MessageReceiverThread()
        self.receive_thread.login_received.connect(self.login_rece)
        self.receive_thread.register_received.connect(self.register_rece)
        self.receive_thread.message_received.connect(self.handle_message_received)
        self.receive_thread.send_map_received.connect(self.handle_send_map_received)
        self.receive_thread.get_map_received.connect(self.handle_get_map_received)
        self.receive_thread.game_invitation.connect(self.game_invitation)
        self.receive_thread.win_or_lose.connect(self.win_or_lose)
        self.receive_thread.invitation_rece.connect(self.invitation_rece)
        self.receive_thread.game.connect(self.game)
        self.receive_thread.online_users_updated.connect(self.handle_online_users_updated)
        self.receive_thread.map.connect(self.map)
        self.receive_thread.start()
        # 多人对战绑定
        # self.receive_thread.game_turn.connect(self.game_turn)
        # # 设置背景图片
        # self.setStyleSheet(
        #     """
        #     QMainWindow {
        #         background-image: url('Asset/UI/bg.jpg');
        #         background-repeat: no-repeat;
        #         background-position: center center; /* Place the background image in the center of the window */
        #         background-color: #000000; /* Set the background color to black */
        #         background-size: cover; /* Adjust the background image to cover the entire window */
        #     }
        #     QPushButton {
        #         font-weight: bold; /* 设置字体加粗 */
        #         font-family: "方正姚体";
        #         background-color: rgba(0, 0, 0, 0.6); /* 设置按钮背景色为黑色，透明度为0.6 */
        #         border-radius: 15px; /* 设置按钮圆角边框 */
        #         color: rgba(255, 255, 255, 1.0); /* 设置字体颜色为白色，透明度为1.0 */
        #     }
        #     QPushButton:hover {
        #         background-color: rgba(0, 0, 0, 0.8); /* 设置鼠标悬停时按钮背景色透明度变低 */
        #     }
        #     QLineEdit {
        #         font-weight: bold; /* 设置字体加粗 */
        #         font-family: "方正姚体";
        #         border-radius: 15px; /* 设置圆角边框 */
        #         background-color: rgba(0, 0, 0, 0.6); /* 设置输入框背景色为黑，透明度为0.6 */
        #         padding: 6px; /* 设置字体与边框之间的间距为6像素 */
        #         color: rgba(255, 255, 255, 1.0); /* 设置字体颜色为白色，透明度为0.5 */
        #     }
        #     QLineEdit:hover {
        #         background-color: rgba(0, 0, 0, 0.8); /* 设置鼠标悬停时按钮背景色透明度变低 */
        #     }
        #     """
        # )

    def change_page(self, page_name):
        if page_name in self.page_index:
            self.stacked.setCurrentIndex(self.page_index[page_name])
        else:
            print(f"Page '{page_name}' not found in page_index.")

    def handle_message_received(self, response):
        self.page4.receive_messages(response)

    def handle_send_map_received(self, response):
        if response == "File received successfully":
            QMessageBox.information(self, "成功", "地图上传成功", QMessageBox.Ok)
        elif response == "Mapname already exists":
            QMessageBox.warning(self, "警告", "地图名已存在", QMessageBox.Ok)
        else:
            QMessageBox.warning(self, "警告", "地图上传失败", QMessageBox.Ok)

    def login_rece(self, response):
        if response == "Login success":
            # 调用父类 MainWindow 实例的 change_page 方法来切换页面
            self.stacked.setCurrentIndex(self.page_index["home_page"])
        elif response == "Login repeat":
            QMessageBox.warning(self, "警告", "用户在其他设备已登录", QMessageBox.Ok)

        elif response == "Login failed":
            QMessageBox.warning(self, "警告", "用户名或密码错误", QMessageBox.Ok)

    def register_rece(self, response):
        if response == "Register success":
            QMessageBox.information(self, "成功", "注册成功", QMessageBox.Ok)
        elif response == "Username already exists":
            QMessageBox.warning(self, "警告", "用户名已存在", QMessageBox.Ok)

    def game_invitation(self, mapname):
        # 弹出消息窗口
        reply = QMessageBox.question(self, "多人联机邀请", f"您确定要接收{sendsocket.recipient}使用地图 {mapname} 发起的对战邀请吗？",
                                     QMessageBox.Ok | QMessageBox.Cancel,
                                     QMessageBox.Ok)


        if  self.page2.multiple:
            file_info = {
                'action': 'invitationrece',
                'recipient': sendsocket.username,
                'response': 'reject'
            }
            # 发送数据
            sendsocket.client_socket.send(json.dumps(file_info).encode('utf-8'))

        if reply == QMessageBox.Ok:
            file_info = {
                'action': 'invitationrece',
                'recipient': sendsocket.recipient,
                'mapname': mapname,
                'response': 'agree'
            }
            # 发送数据
            sendsocket.client_socket.send(json.dumps(file_info).encode('utf-8'))
            # 在这里添加代码以接收对方的同意信息并调用battle函数
            self.start_game(mapname)
        elif reply == QMessageBox.Cancel:
            file_info = {
                'action': 'invitationrece',
                'recipient': sendsocket.username,
                'response': 'reject'
            }
            # 发送数据
            sendsocket.client_socket.send(json.dumps(file_info).encode('utf-8'))
        else:
            pass

    # 接受对战，接收方开始游戏
    def start_game(self,mapname):
        # 发起对战为红方，接受对战为蓝方
        self.window().battle_field(mapname, "blue")

    # 发起对战，发起方开始游戏
    def invitation_rece(self, mapname, response):
        if response == "agree":
            QMessageBox.information(self, "消息", "对方同意了对战", QMessageBox.Ok)
            self.window().battle_field(mapname,"red")
        elif response == "reject":
            QMessageBox.information(self, "消息", "对方拒绝了邀请", QMessageBox.Ok)

    def win_or_lose(self, response):
        if response == "win":
            QMessageBox.information(self, "胜利", "YOU WIN", QMessageBox.Ok)
        elif response == "lose":
            QMessageBox.information(self, "战败", "YOU LOSE", QMessageBox.Ok)

    def game(self, response):
        print(response)

    # 已经取消在主窗口的绑定了
    def game_turn(self, response):
        self.page2.update_turn()
        # QMessageBox.information(self,'消息',f'{response}',QMessageBox.Ok)

    def handle_online_users_updated(self, response):
        self.page4.online_users_rece(response)

    def map(self, response):
        self.page4.maps_rece(response)
        self.page5.maps_rece(response)

    # 多人联机战场界面
    # def battle_field(self, map_path='', faction='red'):
    #     self.stacked.setCurrentIndex(self.page_index["battle_field_page"])
    #     # 如果地图路径为空
    #     # 使用默认地图
    #     if not map_path:
    #         map_path = self.exe_path + "/map/tt.json"
    #     # 设置为多人模式
    #     self.page2.multiple = True
    #     # 更改顺序，加载地图
    #     self.page2.load_map(map_path, faction)
    def battle_field(self, mapname, faction):
        file_info = {
            'action': 'entergame',
            'username': sendsocket.username
        }
        # 发送数据
        sendsocket.client_socket.send(json.dumps(file_info).encode('utf-8'))

        sendsocket.faction = faction
        self.stacked.setCurrentIndex(self.page_index["battle_field_page"])
        # 默认地图路径
        default_map_path = self.exe_path + "/map/tt.json"

        # 设置为多人模式
        self.page2.multiple = True

        # 如果没有提供地图路径，则使用默认地图路径
        if not mapname:
            map_path = default_map_path
        else:
            map_path = f'map/{mapname}.json'

        # 如果指定的地图路径存在，则直接加载该地图
        if os.path.exists(map_path):
            self.page2.load_map(map_path, faction)
        else:
            # 扫描/map/文件夹查找是否有指定文件
            map_files = os.listdir(self.exe_path + "/map/")
            if "tt.json" in map_files:
                map_path = self.exe_path + "/map/tt.json"
                self.page2.load_map(map_path, faction)
            else:
                # 如果没有找到指定文件，则向服务器请求文件
                self.get_map_from_server(mapname)

    def handle_get_map_received(self, map_path):
        # 加载地图
        self.page2.load_map(map_path, sendsocket.faction)

    def get_map_from_server(self, mapname):
        try:
            # login_request = f"login|{username}|{password}"
            # sendsocket.client_socket.sendall(login_request.encode('utf-8'))
            # 准备要发送的数据
            file_info = {
                'action': 'getmap',
                'username': sendsocket.username,
                'mapname': mapname
            }
            # 发送数据
            sendsocket.client_socket.send(json.dumps(file_info).encode('utf-8'))

        except Exception as e:
            print("错误:", e)


    # 人家对战战场界面
    # def battle_field1(self, map_path='111'):
    #     self.stacked.setCurrentIndex(self.page_index["battle_field_page"])
    #     # 导入地图
    #     map_path = self.exe_path + "/map/" + map_path + ".json"
    #     self.page2.load_map(map_path)

    def battle_field1(self, mapname, faction):
        sendsocket.faction = faction
        self.stacked.setCurrentIndex(self.page_index["battle_field_page"])
        # 默认地图路径
        default_map_path = self.exe_path + "/map/tt.json"

        # 设置为多人模式
        #self.page2.multiple = True

        # 如果没有提供地图路径，则使用默认地图路径
        if not mapname:
            map_path = default_map_path
        else:
            map_path = f'map/{mapname}.json'

        # 如果指定的地图路径存在，则直接加载该地图
        if os.path.exists(map_path):
            self.page2.load_map(map_path, faction)
        else:
            # 扫描/map/文件夹查找是否有指定文件
            map_files = os.listdir(self.exe_path + "/map/")
            if "tt.json" in map_files:
                map_path = self.exe_path + "/map/tt.json"
                self.page2.load_map(map_path, faction)
            else:
                # 如果没有找到指定文件，则向服务器请求文件
                self.get_map_from_server(mapname)


    def map_editor(self, map_path=None):
        self.stacked.setCurrentIndex(self.page_index["map_editor_page"])
        if map_path:
            map_path = self.exe_path + "/map/" + map_path + ".json"
            self.page3.map_path = map_path
            self.page3.map()

    def multiplayer(self):
        self.stacked.setCurrentIndex(self.page_index["multiplayer_page"])

    def ai_battle(self):
        self.stacked.setCurrentIndex(self.page_index["ai_battle_page"])

    def home(self):
        self.stacked.setCurrentIndex(self.page_index["home_page"])

    def resizeEvent(self, event) -> None:
        w, h = self.width(), self.height()
        self.page1.setGeometry(0, 0, w, h)
        self.home_page.setGeometry(0, 0, w, h)
        self.page2.setGeometry(0, 0, w, h)
        self.page3.setGeometry(0, 0, w, h)
        self.page4.setGeometry(0, 0, w, h)
        self.page5.setGeometry(0, 0, w, h)


# 登录页面
class LoginPage(QWidget):
    def __init__(self, parent=None, stacked=None):
        super().__init__(parent)
        self.username = None
        self.stacked = stacked
        self.main_window = parent
        self.label = QLabel(self)
        self.label.setAlignment(Qt.AlignCenter)
        self.label.setGeometry(0, 0, 1280, 720)
        self.username_edit = QLineEdit(self)
        self.username_edit.setPlaceholderText("用户名")
        self.username_edit.setGeometry(1280 // 2 - 100, 720 // 2 - 75, 200, 30)
        self.password_edit = QLineEdit(self)
        self.password_edit.setPlaceholderText("密码")
        self.password_edit.setEchoMode(QLineEdit.Password)
        self.password_edit.setGeometry(1280 // 2 - 100, 720 // 2 - 25, 200, 30)

        self.info_label = QLabel(self)  # 用于显示返回信息的标签
        self.info_label.setAlignment(Qt.AlignCenter)
        self.info_label.setGeometry(1280 // 2 - 100, 720 // 2 - 100, 300, 30)

        login_button = QPushButton("登录", self)
        login_button.setGeometry(1280 // 2 - 100, 720 // 2 + 25, 90, 30)
        login_button.clicked.connect(self.login)

        register_button = QPushButton("注册", self)
        register_button.setGeometry(1280 // 2 + 10, 720 // 2 + 25, 90, 30)
        register_button.clicked.connect(self.open_register_window)

        self.register_window = RegisterPage()

    def login(self):
        global username
        username = self.username_edit.text()
        password = self.password_edit.text()
        sendsocket.username = username
        if not username or not password:
            QMessageBox.warning(self, "警告", "请输入用户名和密码", QMessageBox.Ok)
            return
        try:
            # login_request = f"login|{username}|{password}"
            # sendsocket.client_socket.sendall(login_request.encode('utf-8'))
            # 准备要发送的数据
            file_info = {
                'action': 'login',
                'username': username,
                'password': password
            }
            # 发送数据
            sendsocket.client_socket.send(json.dumps(file_info).encode('utf-8'))

        except Exception as e:
            print("错误:", e)

    def open_register_window(self):
        self.register_window.show()


# 注册页面
class RegisterPage(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("注册")
        self.resize(300, 200)
        self.setWindowIcon(QIcon("Asset/UI/move_battle.png"))  # 将 "icon.png" 替换为你想要设置的图标路径
        self.setStyleSheet("background-color: rgba(51, 51, 51, 0.6);color: rgba(255, 255, 255, 0.8); /* 白色字体，透明度0.8 */")
        layout = QVBoxLayout()
        # 加载字体
        font = ''
        font_path = "Asset/fonts/font1.ttf"
        font_id = QFontDatabase.addApplicationFont(font_path)
        if font_id != -1:
            font = QFontDatabase.applicationFontFamilies(font_id)[0]
        self.username_edit = QLineEdit()
        self.username_edit.setPlaceholderText("用户名")
        self.username_edit.setStyleSheet(
            f"""
                    font-weight: bold;
                    font-family: "{font}";
                    border-radius: 15px;
                    background-color: rgba(0, 0, 0, 0.6);
                    padding: 6px;
                    """
        )
        layout.addWidget(self.username_edit)

        self.password_edit = QLineEdit()
        self.password_edit.setPlaceholderText("密码")
        self.password_edit.setEchoMode(QLineEdit.Password)
        self.password_edit.setStyleSheet(
            f"""
                    font-weight: bold;
                    font-family: "{font}";
                    border-radius: 15px;
                    background-color: rgba(0, 0, 0, 0.6);
                    padding: 6px;
                    """
        )
        layout.addWidget(self.password_edit)

        register_button = QPushButton("注册")
        register_button.clicked.connect(self.register)
        register_button.setStyleSheet(
            f"""
                    font-weight: bold;
                    font-family: "{font}";
                    background-color: rgba(0, 0, 0, 0.6);
                    border-radius: 15px;
                    color: rgba(255, 255, 255, 0.5);
                    """
        )
        layout.addWidget(register_button)

        self.setLayout(layout)

        # layout = QVBoxLayout()
        #
        # self.username_edit = QLineEdit()
        # self.username_edit.setPlaceholderText("用户名")
        # layout.addWidget(self.username_edit)
        #
        # self.password_edit = QLineEdit()
        # self.password_edit.setPlaceholderText("密码")
        # self.password_edit.setEchoMode(QLineEdit.Password)
        # layout.addWidget(self.password_edit)
        #
        # register_button = QPushButton("注册")
        # register_button.clicked.connect(self.register)
        # layout.addWidget(register_button)
        #
        # self.setLayout(layout)


    def register(self):
        rusername = self.username_edit.text()
        password = self.password_edit.text()
        if not rusername or not password:
            QMessageBox.warning(self, "警告", "请输入用户名和密码", QMessageBox.Ok)
            # self.show_info("请输入用户名和密码", "warning")
            return
        # 使用正则表达式检查用户名和密码是否只包含数字和英文字母
        if not re.match("^[a-zA-Z0-9]+$", rusername) or not re.match("^[a-zA-Z0-9]+$", password):
            QMessageBox.warning(self, "警告", "用户名和密码只能包含数字和英文字符", QMessageBox.Ok)
            return
        try:
            # login_request = f"register|{rusername}|{password}"
            # sendsocket.client_socket.sendall(login_request.encode('utf-8'))
            # 准备要发送的数据
            file_info = {
                'action': 'register',
                'username': rusername,
                'password': password
            }
            # 发送数据
            sendsocket.client_socket.send(json.dumps(file_info).encode('utf-8'))

            self.close()
        except Exception as e:
            print("错误:", e)


# 主页面
class HomePage(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.label = QLabel(self)
        self.label.setAlignment(Qt.AlignCenter)
        self.label.setGeometry(0, 0, parent.width(), parent.height())
        self.button1 = QPushButton("多人联机", self.label)
        self.button1.clicked.connect(self.multiplayer)
        self.button1.setGeometry(parent.width() // 2 - 100, parent.height() // 2 - 75, 200, 30)
        self.button2 = QPushButton("人机对战", self.label)
        self.button2.clicked.connect(self.ai_battle)
        self.button2.setGeometry(parent.width() // 2 - 100, parent.height() // 2 - 25, 200, 30)
        self.button2 = QPushButton("编辑地图", self.label)
        self.button2.clicked.connect(self.map_editor)
        self.button2.setGeometry(parent.width() // 2 - 100, parent.height() // 2 + 25, 200, 30)
        self.button3 = QPushButton("退出登录", self.label)
        self.button3.clicked.connect(self.logout)
        self.button3.setGeometry(parent.width() // 2 - 100, parent.height() // 2 + 75, 200, 30)

    # 多人联机
    def multiplayer(self):
        # # 首先启动监听服务器消息的线程
        # self.start_server_message_listener()
        # 切换到多人联机页面
        self.window().multiplayer()

    # 人机对战
    def ai_battle(self):
        # 切换到人机对战页面
        self.window().ai_battle()

    # 地图编辑器
    def map_editor(self):
        self.window().map_editor()

    # 退出游戏
    def logout(self):
        # 切换到登录注册页面
        self.window().stacked.setCurrentIndex(self.window().page_index["login_page"])
        # temp = username
        # register_request = f"logout|{temp}"
        # sendsocket.client_socket.sendall(register_request.encode('utf-8'))
        # 准备要发送的数据
        file_info = {
            'action': 'logout',
            'username': username
        }
        # 发送数据
        sendsocket.client_socket.send(json.dumps(file_info).encode('utf-8'))


# 多人游戏页面
class MultiplayerPage(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.label = QLabel(self)
        self.label.setAlignment(Qt.AlignCenter)
        self.label.setGeometry(0, 0, 1280, 720)
        font_family = ''
        font_path = "Asset/fonts/font1.ttf"
        font_id = QFontDatabase.addApplicationFont(font_path)
        if font_id != -1:
            font_family = QFontDatabase.applicationFontFamilies(font_id)[0]
        # 创建一个QFont对象
        font = QFont()
        font.setPointSize(25)
        self.labelHand = QLabel(self.label)
        self.labelHand.setFont(font)  # 设置字体
        self.labelHand.setText("多人联机")
        self.labelHand.setGeometry(parent.width() // 2 - 75, parent.height() // 2 - 125, 150, 50)
        self.labelHand.setStyleSheet(
            """
            QLabel {
                color: white;
                opacity: 0.8;
            }
            """
        )
        self.button1 = QPushButton("开始游戏", self.label)
        self.button1.clicked.connect(self.start_game)
        self.button1.setGeometry(parent.width() // 2 - 100, parent.height() // 2 - 25, 200, 50)
        self.button3 = QPushButton("退出游戏", self.label)
        self.button3.clicked.connect(self.quit_game)
        self.button3.setGeometry(parent.width() // 2 - 100, parent.height() // 2 + 75, 200, 50)

        # # 选择地图
        # self.selected_map = ''
        # self.list_widget_map = QListWidget(self.label)
        # self.list_widget_map.itemClicked.connect(self.select_map)
        # self.load_map()
        # self.list_widget_map.setGeometry(parent.width() // 2 - 100 * 3, parent.height() // 2 - 50, widgetWidth,
        #                                  widgetHeight)

        # 在线玩家列表
        self.online_users = []
        self.online_users_list = QListWidget(self)
        self.online_users_list.setGeometry(10, 10, 200, 720 - 50)
        self.online_users_list.setStyleSheet(
            f"""
                            QListWidget {{
                                background-color: rgba(51, 51, 51, 0.6); /* 透明度0.6的深灰色背景 */
                                color: rgba(255, 255, 255, 0.8); /* 白色字体，透明度0.8 */
                                border: 1px solid #666; /* Medium gray */
                                border-radius: 10px; /* 圆角 */
                                font-weight: bold; /* 设置字体加粗 */
                                font-family: "{font_family}"; /* 使用Python变量 */
                            }}
                            """
        )

        # 刷新按钮
        refresh_button = QPushButton("在线玩家刷新", self)
        refresh_button.setGeometry(10, 720 - 30, 80, 20)
        refresh_button.clicked.connect(self.refresh_online_users)

        # 地图列表
        self.maps = []
        self.maps_list = QListWidget(self)
        self.maps_list.setGeometry(220, 10, 200, 720 - 50)
        self.maps_list.setStyleSheet(
            f"""
                    QListWidget {{
                        background-color: rgba(51, 51, 51, 0.6); /* 透明度0.6的深灰色背景 */
                        color: rgba(255, 255, 255, 0.8); /* 白色字体，透明度0.8 */
                        border: 1px solid #666; /* Medium gray */
                        border-radius: 10px; /* 圆角 */
                        font-weight: bold; /* 设置字体加粗 */
                        font-family: "{font_family}"; /* 使用Python变量 */
                    }}
                    """
        )

        # 地图刷新按钮
        refresh_button1 = QPushButton("地图刷新", self)
        refresh_button1.setGeometry(220, 720 - 30, 80, 20)
        refresh_button1.clicked.connect(self.refresh_maps)

        # # 消息框
        # self.message_box = QTextEdit(self)
        # self.message_box.setGeometry(220, 10, 280, 200)
        # self.message_box.setReadOnly(True)
        #
        # # 文本输入框
        # self.text_input = QLineEdit(self)
        # self.text_input.setGeometry(220, 215, 280, 30)
        #
        # # 发送按钮
        # send_button = QPushButton("发送", self)
        # send_button.setGeometry(290, 250, 120, 30)
        # send_button.clicked.connect(self.send_message)

    # 开始游戏
    def start_game(self):
        selected_item = self.online_users_list.currentItem()  # 获取当前所选项
        if selected_item:
            mapname_item = self.maps_list.currentItem()
            if mapname_item:
                sendsocket.recipient = selected_item.text()
                mapname = mapname_item.text()

                if sendsocket.recipient == sendsocket.username:
                    QMessageBox.warning(self,'警告','不能与自己进行多人对战',QMessageBox.Ok)
                    return
                else:
                    # 准备要发送的数据
                    # 弹出消息窗口
                    reply = QMessageBox.question(self, "多人联机邀请", f"您确定要使用地图 {mapname} 向{sendsocket.recipient}发起对战邀请吗？",
                                                 QMessageBox.Ok | QMessageBox.Cancel,
                                                 QMessageBox.Ok)

                    if reply == QMessageBox.Ok:
                        file_info = {
                            'action': 'game_invitation',
                            'username': username,
                            'mapname': mapname,
                            'recipient': sendsocket.recipient
                        }
                        # 发送数据
                        sendsocket.client_socket.send(json.dumps(file_info).encode('utf-8'))
                        # 在这里添加代码以接收对方的同意信息并调用battle函数
                    elif reply == QMessageBox.Cancel:
                        pass
                    else:
                        pass
                # self.text_input.clear()
            else:
                QMessageBox.warning(self, '警告', '没有选择地图', QMessageBox.Ok)
                # print("No user selected.")
        else:
            QMessageBox.warning(self, '警告', '没有选择对手', QMessageBox.Ok)
            print("Message is empty.")
        selected_item = self.online_users_list.currentItem()  # 获取当前所选项
        sendsocket.recipient = selected_item.text()
        # 切换到战场界面
        # QMessageBox.information(self, "对战邀请", f"您确定要向{sendsocket.recipient}发起对战邀请吗？", QMessageBox.Ok)

    # 退出游戏
    def quit_game(self):
        # 切换到主页
        self.window().stacked.setCurrentIndex(self.window().page_index["home_page"])

    # # 当用户点击列表中的项目时调用的方法
    # def on_item_clicked(self, item):
    #     # s_username = item.text()  # 获取所选项的文本（即用户名）
    #     s_username = "111"
    #     print(f"Selected username: {s_username}")

    # 发送消息
    def send_message(self):
        message = self.text_input.text()
        if message:
            selected_item = self.online_users_list.currentItem()  # 获取当前所选项
            if selected_item:
                # c_username = selected_item.text()  # 获取所选项的用户名
                sendsocket.recipient = selected_item.text()
                # send_message_request = f"send_message|{c_username}|{message}"
                # sendsocket.client_socket.sendall(send_message_request.encode())
                # 准备要发送的数据
                file_info = {
                    'action': 'send_message',
                    'recipient': sendsocket.recipient,
                    'message': message
                }
                # 发送数据
                sendsocket.client_socket.send(json.dumps(file_info).encode('utf-8'))
                self.text_input.clear()
            else:
                print("No user selected.")
        else:
            print("Message is empty.")

    # 接收消息
    def receive_messages(self, response):
        try:
            # 将消息添加到消息框中
            self.message_box.append(response)
        except Exception as e:
            print("错误:", e)

    # 刷新用户列表
    def refresh_online_users(self, online_usernames):
        # c_username = username
        # send_message_request = f"get_online_users|{c_username}"
        # sendsocket.client_socket.sendall(send_message_request.encode())
        # 准备要发送的数据
        file_info = {
            'action': 'get_online_users',
            'username': sendsocket.username
        }
        # 发送数据
        sendsocket.client_socket.send(json.dumps(file_info).encode('utf-8'))

    def refresh_maps(self, online_usernames):
        # c_username = username
        # send_message_request = f"get_online_users|{c_username}"
        # sendsocket.client_socket.sendall(send_message_request.encode())
        # 准备要发送的数据
        file_info = {
            'action': 'get_maps',
            'username': sendsocket.username
        }
        # 发送数据
        sendsocket.client_socket.send(json.dumps(file_info).encode('utf-8'))

    def maps_rece(self, online_usernames):
        maps = online_usernames.split(",")
        # 清空 QListWidget
        self.maps_list.clear()
        # 逐个添加用户名到 QListWidget
        for map in maps:
            # 创建一个 QListWidgetItem，并设置其文本为用户名
            item = QListWidgetItem(map)
            # 将 QListWidgetItem 添加到 QListWidget 中
            self.maps_list.addItem(item)

    def online_users_rece(self, online_usernames):
        # 假设接收到的消息格式为 "username1|username2|username3"
        usernames = online_usernames.split(",")
        # 清空 QListWidget
        self.online_users_list.clear()
        # 逐个添加用户名到 QListWidget
        for username in usernames:
            # 创建一个 QListWidgetItem，并设置其文本为用户名
            item = QListWidgetItem(username)
            # 将 QListWidgetItem 添加到 QListWidget 中
            self.online_users_list.addItem(item)

    # 重绘事件处理函数
    def repaint(self) -> None:
        super().repaint()

    def select_map(self):
        selected_items = self.maps_list.selectedItems()
        if selected_items:
            item = self.maps_list.itemWidget(selected_items[0])
            self.selected_map = item.name

        # 导入文件夹全部地图

    def load_map(self):
        path = Tool.where() + "/map"
        fs = Tool.get_all(path)
        for f in fs:
            item = Item(f, itemWidth, itemHeight)
            list_item = QListWidgetItem()
            list_item.setSizeHint(item.size())
            self.maps_list.addItem(list_item)
            self.maps_list.setItemWidget(list_item, item)


# 块选择框类
class Item(QWidget):
    def __init__(self, path, width, height):
        super().__init__()
        # 路径
        self.path = path
        self.name = path.split('/')[-1].split('.')[0]
        # 框架
        self.label = self.name_label()
        # 几何
        self.set_size(width, height)

    def name_label(self):
        label = QLabel(self)
        label.setText(self.name)
        font = QFont()
        font.setPixelSize(12)
        label.setFont(font)
        label.setAlignment(Qt.AlignCenter)
        return label

    def set_size(self, w, h):
        self.resize(w, h)
        self.label.setGeometry(0, 0, w, h)


# 人机对战页面
class AIBattlePage(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.label = QLabel(self)
        self.label.setAlignment(Qt.AlignCenter)
        self.label.setGeometry(0, 0, 1280, 720)
        font_family = ''
        font_path = "Asset/fonts/font1.ttf"
        font_id = QFontDatabase.addApplicationFont(font_path)
        if font_id != -1:
            font_family = QFontDatabase.applicationFontFamilies(font_id)[0]
        # 创建一个QFont对象
        font = QFont()
        font.setPointSize(25)
        font.setFamily(font_family)
        self.labelHand = QLabel(self.label)
        self.labelHand.setFont(font)  # 设置字体
        self.labelHand.setText("人机对战")
        self.labelHand.setGeometry(parent.width() // 2 - 75, parent.height() // 2 - 125, 150, 50)

        self.button1 = QPushButton("开始游戏", self.label)
        self.button1.clicked.connect(self.start_medium_game)
        self.button1.setGeometry(parent.width() // 2 - 100, parent.height() // 2 - 25, 200, 50)
        self.button3 = QPushButton("退出游戏", self.label)
        self.button3.clicked.connect(self.quit_game)
        self.button3.setGeometry(parent.width() // 2 - 100, parent.height() // 2 + 75, 200, 50)

        # 地图列表
        self.maps = []
        self.maps_list = QListWidget(self)
        self.maps_list.setGeometry(10, 10, 200, 720 - 50)
        self.maps_list.setStyleSheet(
            f"""
                    QListWidget {{
                        background-color: rgba(51, 51, 51, 0.6); /* 透明度0.6的深灰色背景 */
                        color: rgba(255, 255, 255, 0.8); /* 白色字体，透明度0.8 */
                        border: 1px solid #666; /* Medium gray */
                        border-radius: 10px; /* 圆角 */
                        font-weight: bold; /* 设置字体加粗 */
                        font-family: "{font_family}"; /* 使用Python变量 */
                    }}
                    """
        )

        # 地图刷新按钮
        refresh_button1 = QPushButton("地图刷新", self)
        refresh_button1.setGeometry(10, 720 - 30, 80, 20)
        refresh_button1.clicked.connect(self.refresh_maps)

        # # self.button1 = QPushButton("简单模式", self.label)
        # # self.button1.clicked.connect(self.start_easy_game)
        # # self.button1.setGeometry(parent.width() // 2 - 100, parent.height() // 2 - 75, 200, 30)
        # self.button2 = QPushButton("普通模式", self.label)
        # self.button2.clicked.connect(self.start_medium_game)
        # self.button2.setGeometry(parent.width() // 2 - 100, parent.height() // 2 - 25, 200, 30)
        # # self.button3 = QPushButton("困难模式", self.label)
        # # self.button3.clicked.connect(self.start_hard_game)
        # # self.button3.setGeometry(parent.width() // 2 - 100, parent.height() // 2 + 25, 200, 30)
        # self.button3 = QPushButton("退出游戏", self.label)
        # self.button3.clicked.connect(self.quit_game)
        # self.button3.setGeometry(parent.width() // 2 - 100, parent.height() // 2 + 75, 200, 30)
        #
        # # 开始简单难度游戏
        # # 选择地图
        # self.selected_map = ''
        # self.list_widget_map = QListWidget(self.label)
        # self.list_widget_map.itemClicked.connect(self.select_map)
        # self.load_map()
        # self.list_widget_map.setGeometry(parent.width() // 2 - 100 * 3, parent.height() // 2 - 50, widgetWidth,
        #                                  widgetHeight)

    def refresh_maps(self, online_usernames):
        # c_username = username
        # send_message_request = f"get_online_users|{c_username}"
        # sendsocket.client_socket.sendall(send_message_request.encode())
        # 准备要发送的数据
        file_info = {
            'action': 'get_maps',
            'username': sendsocket.username
        }
        # 发送数据
        sendsocket.client_socket.send(json.dumps(file_info).encode('utf-8'))

    def maps_rece(self, online_usernames):
        maps = online_usernames.split(",")
        # 清空 QListWidget
        self.maps_list.clear()
        # 逐个添加用户名到 QListWidget
        for map in maps:
            # 创建一个 QListWidgetItem，并设置其文本为用户名
            item = QListWidgetItem(map)
            # 将 QListWidgetItem 添加到 QListWidget 中
            self.maps_list.addItem(item)

    # 开始简单难度游戏
    def start_easy_game(self):
        # 在这里添加开始简单难度游戏的逻辑
        pass

    # 开始中等难度游戏
    def start_medium_game(self):
        mapname = self.maps_list.currentItem().text()
        self.window().battle_field1(mapname, 'red')

    # 开始困难难度游戏
    def start_hard_game(self):
        # 在这里添加开始困难难度游戏的逻辑
        pass

    def quit_game(self):
        # 切换到主页
        self.window().stacked.setCurrentIndex(self.window().page_index["home_page"])

    # 重绘事件处理函数
    def repaint(self) -> None:
        super().repaint()

    # def select_map(self):
    #     selected_items = self.list_widget_map.selectedItems()
    #     if selected_items:
    #         item = self.list_widget_map.itemWidget(selected_items[0])
    #         self.selected_map = item.name

    # 导入文件夹全部地图
    # def load_map(self):
    #     path = Tool.where() + "/map"
    #     fs = Tool.get_all(path)
    #     for f in fs:
    #         item = Item(f, itemWidth, itemHeight)
    #         list_item = QListWidgetItem()
    #         list_item.setSizeHint(item.size())
    #         self.list_widget_map.addItem(list_item)
    #         self.list_widget_map.setItemWidget(list_item, item)


# 客户端开始运行
def run():
    app = QApplication([])
    # Set the style sheet for QMessageBox
    style_sheet = """
        QMessageBox {
            background-color: rgba(51, 51, 51, 0.6); /* 透明度0.6的深灰色背景 */
                color: rgba(255, 255, 255, 0.5); /* 白色字体，透明度0.8 */
                border: 1px solid #666; /* Medium gray */
                border-radius: 10px; /* 圆角 */
        }
        QMessageBox QLabel {
            background-color: rgba(51, 51, 51, 0.6); /* 透明度0.6的深灰色背景 */
                color: rgba(255, 255, 255, 1.0); /* 白色字体，透明度0.8 */
                border: 1px solid #666; /* Medium gray */
                border-radius: 10px; /* 圆角 */
        }
        QMessageBox QPushButton {
           background-color: rgba(51, 51, 51, 0.6); /* 透明度0.6的深灰色背景 */
                color: rgba(255, 255, 255, 1.0); /* 白色字体，透明度0.8 */
                border: 1px solid #666; /* Medium gray */
                border-radius: 10px; /* 圆角 */
        }
        QMessageBox QPushButton:hover {
            background-color: rgba(51, 51, 51, 0.6); /* 透明度0.6的深灰色背景 */
                color: rgba(255, 255, 255, 1.0); /* 白色字体，透明度0.8 */
                border: 1px solid #666; /* Medium gray */
                border-radius: 10px; /* 圆角 */
        }
        """
    app.setStyleSheet(style_sheet)
    window = MainWindow()
    window.show()
    app.exec()


if __name__ == "__main__":
    run()
