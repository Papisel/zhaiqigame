from Unit import Unit


# 战斗行动
def is_fight_back(attacker: Unit, defender: Unit):
    defender_damage = damage_calc(attacker, defender)
    if defender.get_cur_stats()["health"] > defender_damage:
        return True
    else:
        return False


# 伤害计算
def damage_calc(attacker: Unit, defender: Unit):
    a, d = attacker.get_cur_stats(), defender.get_cur_stats()
    # 初始值
    res = a["attack"]
    # 攻击类型与防御类型
    if a["attack_type"] == 1 or d["armor"] == 1:
        res *= 1.0
    elif a["attack_type"] == d["armor"]:
        res *= 1.5
    else:
        res *= 0.5
    # 血量消弱攻击
    ratio = a["health"] / attacker.get_stats()["health"]
    if ratio > 0.75:
        res *= 1.0
    elif ratio > 0.5:
        res *= 0.75
    elif ratio > 0.25:
        res *= 0.5
    elif ratio > 0:
        res *= 0.25
    else:
        res = 0
    # 返回伤害
    return int(res)
