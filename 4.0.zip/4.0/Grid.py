import json

from PySide6.QtWidgets import QWidget, QMessageBox

import Block
import Unit
import Tool
import Path
import Battle
from AI import AI as ai
from GridScene import GridScene as Scene
from GridView import GridView as Viewer
from Hint import Hint

import sendsocket


class Grid(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        # 地图视窗
        self.viewer = Viewer(self)
        # 详情显示
        self.hint = Hint(self)
        # 地图编辑模式
        self.editor_mode = False
        # 多人游戏
        self.multiple = False
        # 类初始化
        Block.load_stats()
        Unit.load_stats()
        # 阵营
        self.faction = 'red'
        self.your_turn = True
        # 选择的单位
        self.select_unit = None
        self.bfs_res = None
        self.ai = None

    # 发送行动到服务器
    def multiple_send_action(self, index, actions, defender_index=-1, Firster_index=-1):
        data = {"index": index, "actions": actions, "defender_index": defender_index, "Firster_index": Firster_index}
        # 发过去，告诉对手我行动了
        file_info = {
            'action': 'battle',
            'recipient': sendsocket.recipient,
            'response': str(data)
        }
        # 发送数据
        sendsocket.client_socket.send(json.dumps(file_info).encode('utf-8'))

    # 多人绑定
    def multiple_game(self):
        # print("多人游戏绑定")
        # 对面发送了战斗
        self.window().receive_thread.update_battle.connect(self.multiple_battle)
        # 对面告诉我到我的回合了
        self.window().receive_thread.game_turn.connect(self.multiple_update_turn)
        # 对面告诉我我赢了
        self.window().receive_thread.win_or_lose.connect(self.win)

    # 多人战斗解析
    def multiple_battle(self, respond):
        respond = eval(respond)
        # # 解析
        index = int(respond["index"])
        actions = respond["actions"]
        defender_index = respond["defender_index"]
        Firster_index = respond["Firster_index"]
        res = []
        for action in actions:
            res.append(tuple(action))
        # 行动
        self.viewer.scene().update_unit(index, res, defender_index, Firster_index)

    # 多人回合更换
    def multiple_update_turn(self, respond):
        self.update_turn()

    # 导入地图
    def load_map(self, map_path, faction='red'):
        # 先手，默认红方先手
        self.faction = faction
        if self.faction == 'red':
            self.your_turn = True
        else:
            self.your_turn = False
        self.hint.display_turn(self.faction, self.your_turn)
        # 地图场景
        scene = Scene(self)
        self.viewer.setScene(scene)
        scene.load(map_path, faction)
        self.viewer.centerOn(56 * 5, 56 * 5)
        # 如果是多人游戏
        if self.multiple:
            self.multiple_game()
        else:
            self.ai = ai(scene)

    # 导出地图
    def save_map(self, map):
        basic = map["block_map"]
        w, h = basic["size"]
        #无效地图，Scene不存在
        if not self.viewer.scene():
            return False
        # 地形
        for x in range(w):
            for y in range(h):
                item = self.viewer.scene().RBlocks[(x, y)]
                basic["block"][y][x] = item.terrain
        # 单位
        for unit in self.viewer.scene().UBlocks.values():
            data = Unit.blank_unit(unit.name, unit.faction, unit.coordinate)
            map["unit_map"]["unit"].append(data)
        Tool.save_json("map/" + basic["name"], map)
        #无效地图
        return True

    # 接收地块点击
    def accept_block(self, block):
        # 地图编辑模式
        if self.editor_mode:
            # 放置地形
            if self.parent().selected_terrain:
                name = self.parent().selected_terrain
                block.set_terrain(name)
            # 放置单位
            if self.parent().selected_entity:
                faction, name = self.parent().selected_entity.split("_")
                coordinate = block.coordinate
                data = Unit.blank_unit(name, faction, coordinate)
                self.viewer.scene().add_unit(data)
        # 游戏模式
        else:
            # 展示地块
            self.hint.display_block(block)
            # 选择了单位
            if unit := self.select_unit:
                # 单位可以行动
                if self.your_turn and unit.faction == self.faction and unit.ready:
                    # 取选中的地块坐标
                    goal = block.coordinate
                    # 单位寻路
                    path = Path.bfs_recursive(self.bfs_res, self.select_unit, goal, 'move')
                    # 单位行动
                    actions = Path.path2action(path, 'move')
                    if actions:
                        self.viewer.scene().update_unit(self.select_unit.index, actions)
                        # 单位行动了
                        self.select_unit.reverse_ready(self.faction)
                        # 多人游戏发送行动
                        if self.multiple:
                            self.multiple_send_action(self.select_unit.index, actions)
                # 清空
                self.clear_bfs()

    # 接受单位点击,保存所点击单位的信息以及该单位可到达的点
    def accept_unit(self, unit):
        # 地图编辑模式
        if self.editor_mode:
            self.viewer.scene().remove_unit_for_editor(unit)
            return
        # 如果已经有选择了的本方单位并且第二次选择的单位在可攻击列表中
        if self.select_unit and (tuple(unit.coordinate) in self.bfs_res[2]):
            # 单位可以行动
            if self.your_turn and self.select_unit.faction == self.faction and self.select_unit.ready:
                # 单位寻路
                path = Path.bfs_recursive(self.bfs_res, self.select_unit, unit.coordinate, 'battle')
                # 单位行动
                actions = Path.path2action(path, 'battle')
                self.select_unit.reverse_ready(self.faction)
                # 战斗发生了，播放动画
                fight_back = Battle.is_fight_back(self.select_unit, unit)
                if fight_back:
                    action = [(actions[-1][0], (actions[-1][1] + 2) % 4)]
                    self.viewer.scene().update_unit(self.select_unit.index, actions, unit.index, self.select_unit.index)
                    self.viewer.scene().update_unit(unit.index, action, self.select_unit.index, self.select_unit.index)
                    #多人游戏发送行动
                    if self.multiple:
                        self.multiple_send_action(self.select_unit.index, actions, unit.index, self.select_unit.index)
                        self.multiple_send_action(unit.index, action, self.select_unit.index, self.select_unit.index)
                else:
                    self.viewer.scene().update_unit(self.select_unit.index, actions, unit.index, -1)
                    # 多人游戏发送行动
                    if self.multiple:
                        self.multiple_send_action(self.select_unit.index, actions, unit.index, -1)

                # 战斗裁定
                self.viewer.scene().battle_unit = (self.select_unit, unit)
                self.clear_bfs()
                return
        # 选择新单位
        self.clear_bfs()
        self.select_unit = unit
        # 展示单位
        self.hint.display_unit(unit)
        # 保存单位的移动范围
        res = Path.bfs(self.viewer.scene(), unit)
        self.bfs_res = res
        # 展示单位的行动范围
        self.viewer.scene().display_unit_range(res)

    def winlose(self):
        file_info = {
            'action': 'winorlose',
            'username' : sendsocket.username,
            'recipient': sendsocket.recipient,
            'winner' : sendsocket.recipient
        }
        # 发送数据
        sendsocket.client_socket.send(json.dumps(file_info).encode('utf-8'))
        QMessageBox.information(self, '提示', '你输了', QMessageBox.Ok)
        self.quit_game()

    # 清除状态
    def clear_bfs(self):
        # 清空
        self.select_unit = None
        self.bfs_res = None
        # 清空标记
        self.viewer.scene().clear_unit_display()

    # 退出游戏
    def quit_game(self):
        file_info = {
            'action': 'exitgame',
            'username': sendsocket.username
        }
        # 发送数据
        sendsocket.client_socket.send(json.dumps(file_info).encode('utf-8'))

        # 地图编辑模式
        self.editor_mode = False
        # 多人游戏
        self.multiple = False
        # 阵营
        self.faction = 'red'
        self.your_turn = True
        # 选择的单位
        self.clear_bfs()
        self.ai = None
        self.window().home()

    # 过一回合
    def next_turn(self):
        # 过回合
        if self.your_turn:
            self.your_turn = False
            # 更新所有己方单位的可行动
            self.viewer.scene().update_ready_unit(self.faction, False)
            # 发过去，告诉对手到它的回合了
            if self.multiple:
                file_info = {
                    'action': 'gameturn',
                    'recipient': sendsocket.recipient,
                    'response': '你的回合'
                }
                # 发送数据
                sendsocket.client_socket.send(json.dumps(file_info).encode('utf-8'))
                QMessageBox.information(self, '提示', '对手的回合', QMessageBox.Ok)
            # 对手回合
            self.viewer.scene().allFinish = False
            # 多人不进行
            if not self.multiple:
                self.ai.ai_do()
            # 回合显示更新
            self.hint.display_turn(self.faction, self.your_turn)
        else:
            pass

    # 更新回合操作
    def update_turn(self):
        self.your_turn = True
        # 更新所有己方单位的可行动
        self.viewer.scene().update_ready_unit(self.faction, True)
        # 你的回合
        self.hint.display_turn(self.faction, self.your_turn)
        #
        QMessageBox.information(self, '提示', '你的回合', QMessageBox.Ok)

    # 胜负判断
    def win_or_lost(self, faction):
        # 无事发生
        if not faction:
            return
        # 游戏结束，不需要告知对方，本地显示后退出
        if self.faction == faction:
            # print("you lost")
            self.winlose()
            #QMessageBox.information(self, '提示', '你输了', QMessageBox.Ok)
            self.quit_game()
        else:
            # print("you win")
            pass
            #QMessageBox.information(self, '提示', '你赢了', QMessageBox.Ok)

    def win(self):
        print('win')
        QMessageBox.information(self, '提示', '你赢了', QMessageBox.Ok)
        self.quit_game()

    # 设置各部件位置
    def resizeEvent(self, event) -> None:
        w, h = self.width(), self.height()
        # 地图编辑模式
        if self.editor_mode:
            self.hint.setVisible(False)
            self.viewer.setGeometry(0, 0, w, h)
        else:
            self.hint.setGeometry(0, 0, 240, h)
            width = self.hint.width()
            self.viewer.setGeometry(width, 0, w - width, h)
