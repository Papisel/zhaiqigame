from queue import Queue

import Block
import Path
import Battle

class AI:
    def __init__(self, scene, faction='blue'):
        # AI的阵营
        self.AI_Faction = faction
        # AI对手也就是玩家的阵营
        self.Player_Faction = 'red' if self.AI_Faction == 'blue' else 'blue'
        # 当前场景
        self.scene = scene
        # 所有的地形格，键是坐标，值是Block对象
        self.RBlocks = scene.RBlocks
        # AI选择的单位
        self.select_unit = None
        # AI选择的单位的策略
        self.select_unit_tactics = ''
        # BFS搜索结果
        self.bfs_res = None
        self.came_from = None
        self.move_target = None
        self.battle_target = None
        # 所有的ai方单位
        self.AI_UBlocks: [int, Block] = {}
        # 暂时不能动待执行的单位
        self.tmp_queue = Queue()

    def ai_do(self):
        # 遍历所有的AI阵营的可选单位
        # 获取新的ai方单位表之前要先置空一下AI_UBlocks表，否则会出现没删干净情况而报错
        # 为什么要创建一个新表？因为直接在原来这个表中改会报如下错误
        # RuntimeError: dictionary changed size during iteration
        self.AI_UBlocks.clear()
        for select in self.scene.UBlocks.items():
            # ai方
            if select[1].faction == self.AI_Faction:
                self.AI_UBlocks[select[0]] = select[1]
        for select in self.AI_UBlocks.values():
            # ai选择的单位
            print(select.index)
            self.select_unit = select
            # ai选择的单位在当前场景下bfs遍历之后的可选择结点
            self.bfs_res = Path.bfs(self.scene, self.select_unit)
            self.came_from = self.bfs_res[0]
            self.move_target = self.bfs_res[1]
            self.battle_target = self.bfs_res[2]

            # 第一轮遍历中暂时不能动的单位就先存进去
            if not self.bfs_res[1]:
                self.tmp_queue.put(self.select_unit.index)
                # self.select_unit.reverse_ready(self.Player_Faction)
                continue

            # ai选择的下一个点
            tactics, goal = self.ai_choose()

            if tactics == 'move':
                # 单位寻路
                path = Path.bfs_recursive(self.bfs_res, self.select_unit, goal, 'move')
                # 单位行动
                actions = Path.path2action(path, 'move')
                if actions:
                    # 更新坐标并播放动画
                    self.scene.update_unit(self.select_unit.index, actions, -1, -1, True)
            elif tactics == 'battle':
                # 单位寻路
                path = Path.bfs_recursive(self.bfs_res, self.select_unit, goal, 'battle')
                # 单位行动
                actions = Path.path2action(path, 'battle')
                # 战斗发生了，播放动画
                unit = self.scene.is_unit_here(goal, True)
                fight_back = Battle.is_fight_back(self.select_unit, unit)
                print(fight_back)
                if fight_back:
                    action = [(actions[-1][0], (actions[-1][1] + 2) % 4)]
                    self.scene.update_unit(self.select_unit.index, actions, unit.index, self.select_unit.index, True)
                    self.scene.update_unit(unit.index, action, self.select_unit.index, self.select_unit.index, True)
                else:
                    self.scene.update_unit(self.select_unit.index, actions, unit.index, -1, True)
                # 战斗裁定
                self.scene.battle_unit = (self.select_unit, unit)
            self.select_unit.reverse_ready(self.Player_Faction)

    # ai决策
    def ai_choose(self):
        tactics = self.ai_tactics()
        goal: tuple = self.select_unit.coordinate
        goal_set = False  # 标志变量，用于跟踪是否设置了goal
        if self.battle_target and tactics == 'battle':
            # 测试赋值
            tactics = 'battle'
            for target in self.battle_target:
                unit = self.scene.is_unit_here(target, True)
                fight_back = Battle.is_fight_back(self.select_unit, unit)
                select_unit_damage = Battle.damage_calc(unit, self.select_unit)
                # 如果对方可以还击并且自己会被击败，就不选之
                if fight_back and self.select_unit.get_cur_stats()["health"] <= select_unit_damage:
                    continue
                goal = target  # 如果条件满足，设置goal
                goal_set = True  # 设置标志变量为True
            if not goal_set:
                # 测试赋值
                tactics = 'move'
                goal = self.bfs_res[1][-2]
        else:
            # 测试赋值
            tactics = 'move'
            goal = self.bfs_res[1][-2]
        return tactics, goal

    def ai_tactics(self):
        return 'run away' if self.select_unit.name == 'boat6' else 'battle'




