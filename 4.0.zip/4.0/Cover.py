from PySide6.QtWidgets import QGraphicsRectItem, QGraphicsPixmapItem
from PySide6.QtCore import Qt, QRect
from PySide6.QtGui import QPixmap

import Tool

# 定义方格的宽度和高度,这里是统一像素方格标准为64*64
length = 56


# 定义方格类，继承子QGraphicsRectItem矩形框架类
class Cover(QGraphicsRectItem):
    def __init__(self, coordinate: tuple[int, int]):
        super().__init__()
        # 坐标
        self.coordinate = coordinate
        # 设置矩形
        x, y = coordinate  # 获取坐标
        rect = QRect(x * length, y * length, length, length)  # 根据坐标和方格的宽度和高度创建一个矩形
        self.setRect(rect)  # 设置为矩形形状
        # 标记绘制
        self.mark_item = QGraphicsPixmapItem(self)  # 创建一个图片项
        self.mark_item.setPos(rect.topLeft())  # 设置图片项的位置为方格的左上角
        # 设置边框
        self.setPen(Qt.NoPen)
        self.setBrush(Qt.NoBrush)  # 设置方格的填充为无

    def set_mode(self, mode):
        # 图片
        path = mark2path(mode)
        pixmap = QPixmap(path)
        self.mark_item.setPixmap(pixmap)

    def clear_mode(self):
        pixmap = QPixmap()
        self.mark_item.setPixmap(pixmap)


# 根据地形名返回改地形应用图片的地址
def mark2path(mode):
    path = Tool.where() + "/Asset/UI"  # 当前文件相对地址下的资源文件夹下的资源文件下
    image_path = path + f'/{mode}.png'  # 指定的地形图片地址
    return image_path  # 返回结果
