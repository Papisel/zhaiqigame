/*
 Navicat MySQL Data Transfer

 Source Server         : database_1
 Source Server Type    : MySQL
 Source Server Version : 50742
 Source Host           : localhost:3306
 Source Schema         : zhanqigame

 Target Server Type    : MySQL
 Target Server Version : 50742
 File Encoding         : 65001

 Date: 15/05/2024 19:19:03
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for gamerecords
-- ----------------------------
DROP TABLE IF EXISTS `gamerecords`;
CREATE TABLE `gamerecords`  (
  `record` int(50) NOT NULL,
  `username1` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `username2` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `time` int(50) NULL DEFAULT NULL,
  `winner` int(50) NULL DEFAULT NULL,
  PRIMARY KEY (`record`) USING BTREE,
  INDEX `username1`(`username1`) USING BTREE,
  INDEX `username2`(`username2`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

SET FOREIGN_KEY_CHECKS = 1;
