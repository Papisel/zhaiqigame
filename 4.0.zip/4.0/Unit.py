from PySide6.QtWidgets import QGraphicsRectItem, QGraphicsPixmapItem
from PySide6.QtCore import QRect, Qt
from PySide6.QtGui import QPixmap
import Tool

# 定义方格的宽度和高度,这里是统一像素方格标准为64*64
length = 56
# 动画移动速度，即一次timer中移动的像素值
Move = 7


def blank_unit(name, faction, coordinate):
    data = {
        "name": name,
        "faction": faction,
        "damage": 0,
        "coordinate": [coordinate[0], coordinate[1]]
    }
    return data


# 定义单位方格类，继承子QGraphicsRectItem矩形框架类
class Unit(QGraphicsRectItem):
    stats: dict

    def __init__(self, index: int, unit: dict):
        super().__init__()
        # 索引
        self.index = index
        # 数据
        self.name = unit["name"]  # 单位类型
        self.faction = unit["faction"]  # 单位阵营
        self.damage = unit["damage"]  # 累计伤害
        self.coordinate = unit["coordinate"]  # 当前位置
        self.ready = True  # 单位可行动
        # 单位的动画效果
        self.offset = 0
        self.mode = 'move'
        self.move = 0
        # 设置矩形
        x, y = self.coordinate  # 获取坐标
        rect = QRect(x * length, y * length, length, length)  # 根据坐标和方格的宽度和高度创建一个矩形
        self.setRect(rect)  # 设置为矩形形状
        # 设置边框
        self.setPen(Qt.NoPen)
        self.setBrush(Qt.NoBrush)  # 设置方格的填充为无
        # 单位绘制
        self.unit_item = QGraphicsPixmapItem(self)  # 创建一个图片项
        # 初始化绘制，只播放一帧，移动0格
        self.update_animation(0, 0)
        # 单位的可行动与不可行动
        self.ready_item = QGraphicsPixmapItem(self)  # 创建一个图片项
        self.ready_item.setPos(rect.topLeft())  # 设置图片项的位置为方格的左上角

    # 接受鼠标左键
    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:  # 如果按下的是鼠标左键，就触发事件
            grid = self.scene().views()[0].parent()
            grid.accept_unit(self)  # 接受

    # 单位属性
    def get_stats(self):
        return Unit.stats[self.name]

    # 单位现在的属性
    def get_cur_stats(self):
        ori = Unit.stats[self.name]
        res = {"name": ori["name"],
               "health": ori["health"] - self.damage,
               "armor": ori["armor"],
               "attack": ori["attack"],
               "attack_type": ori["attack_type"],
               "move": ori["move"],
               "move_type": ori["move_type"]}
        return res

    # 单位移动
    def update_coordinate(self, direction):
        # 坐标系原点在左上角，右是x轴正方向，下是y轴正方向
        # 右 0 -> 下 1 -> 左 2 -> 上 3
        match direction:
            case 0:
                self.coordinate[0] += 1
            case 1:
                self.coordinate[1] += 1
            case 2:
                self.coordinate[0] -= 1
            case 3:
                self.coordinate[1] -= 1

    # 更新动画
    def update_animation(self, direction, delta=1):

        # 加载图像：从指定路径加载图像文件到QPixmap对象中
        path = unit2path(self.faction, self.name, self.mode)

        # 读取图片路径，原图，整图
        ori = QPixmap(path)

        # 获取图像尺寸：从QPixmap对象获取图像的宽度和高度
        o_w, o_h = ori.width(), ori.height()

        # 计算单个动作的宽度：将图像宽度除以4，假设图像包含4个动作的序列
        s_w = o_w // 4

        # 根据模式计算s_h和index：
        n = 14
        if self.mode == 'move':
            s_h = o_h // 4
            self.offset = (self.offset + 1) % 4
            s_h_index = self.offset
        elif self.mode == 'battle':
            # 如果模式是战斗，计算战斗动作的数量和每个动作的高度
            n = o_h // s_w
            s_h = o_h // n
            self.offset += 1
            s_h_index = self.offset % n

        # 计算裁剪矩形：根据方向和计算出的s_h_index确定裁剪区域
        pixmap_rect = QRect(s_w * direction, s_h * s_h_index, s_w, s_h)

        # 计算差值
        p_x, p_y = 0, 0

        # 这一段非常重要，是直面之前回避的问题的
        # 计算绘制左上角
        if self.mode == 'move':
            if o_w == o_h:
                p_x, p_y = 0, 0
            elif o_w < o_h:
                p_x, p_y = 0, 56
        elif self.mode == 'battle':
            p_x, p_y = 44, 44

        # 在rect的基础上减去差值，得到图片的渲染起点
        self.unit_item.setPos(self.rect().topLeft().x() - p_x, self.rect().topLeft().y() - p_y)

        # 裁剪图像到相应部分：从原始图像中裁剪出指定区域的图像
        pixmap = ori.copy(pixmap_rect)
        # 图片拉伸
        # pixmap = pixmap.scaled(length, length, Qt.AspectRatioMode.IgnoreAspectRatio)
        # 更新图像项：将裁剪后的图像设置到图像项中，并向右移动5个单位
        self.unit_item.setPixmap(pixmap)

        # 移动时移动整个矩形
        if (self.mode == 'move') and delta:
            dx, dy = 0, 0
            # 根据方向设置dx和dy的值
            if direction == 0:
                dx, dy = Move, 0
            elif direction == 1:
                dx, dy = 0, Move
            elif direction == 2:
                dx, dy = -Move, 0
            elif direction == 3:
                dx, dy = 0, -Move

            # 移动图像项
            self.moveBy(dx, dy)

            # 如果move是一个全局变量，确保在函数外部定义它
            # 并在这里递增它的值
            self.move += Move

        # 结束，移动播放结束或战斗播放结束
        if (((self.mode == 'move') and (self.move >= delta * length))
                or ((self.mode == 'battle') and (self.offset >= n))):
            self.move = 0
            self.offset = 0
            # 战斗后重置为移动的第一帧
            if self.mode == 'battle':
                self.mode = 'move'
                self.update_animation(direction, 0)
            return True
        else:
            return False

    # 单位的可行动状态取反
    def reverse_ready(self, faction):
        self.ready = not self.ready
        # 状态更新后更新图片
        self.update_ready_item(faction)

    # 更新单位的可行动状态
    def update_ready_item(self, faction):
        # 图片
        if self.ready and self.faction == faction:
            path = Tool.where() + "/Asset/UI/select_1.png"
            pixmap = QPixmap(path)
        # elif self.ready and self.faction != faction:
        #     print(self.name)
        #     path = Tool.where() + "/Asset/UI/select_2.png"
        #     pixmap = QPixmap(path)
        else:
            pixmap = QPixmap()
        self.ready_item.setPixmap(pixmap)


# 根据单位返回单位对应的图片路径
def unit2path(faction, name, mode):
    path = Tool.where() + "/Asset/Entity"  # 当前文件相对地址下的资源文件夹下的资源文件下
    path += f'/{faction}'  # 单位阵营
    path += f'/{name}_{mode}.png'  # 单位类型
    return path  # 返回结果


# 导入全部单位属性
def load_stats():
    path = Tool.where() + "/Asset/entity.json"
    Unit.stats = Tool.load_json(path)
