import json
import os


# 工具类，包括文件读取封装

# 获取一个文件夹下的全部文件
def get_all(path: str):
    fs = os.listdir(path)
    for i in range(len(fs)):
        fs[i] = path + '/' + fs[i]
    return fs


# 读取文件并输出为列表
def get_data(path: str):
    res = []
    fs = get_all(path)
    for f in fs:
        data = load_json(f)
        res.append(data)
    return res


# 工作目录
def where():
    directory = os.getcwd()
    directory = directory.replace("\\", "/")
    return directory


# 相对路径
def here(path: str):
    return path.replace(where(), '')


# 文本读取
def load_json(path):
    with open(path, 'r', encoding='utf-8') as file:
        data = json.load(file)
        return data


# 文本写入
def save_json(path, data):
    with open(path + '.json', 'w') as file:
        json.dump(data, file, indent=4)


if __name__ == "__main__":
    print("工具")
    pass
