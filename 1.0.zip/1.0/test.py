from PySide6.QtWidgets import QGraphicsScene, QGraphicsView, QGraphicsPixmapItem, QApplication
from PySide6.QtCore import QRect, QTimer
from PySide6.QtGui import QPixmap
import sys


def update_animation(direction, path):
    global index
    index = (index + 1) % 4
    # 加载图像
    original_pixmap = QPixmap(path)
    # 获取图像尺寸
    o_w = original_pixmap.width()
    o_h = original_pixmap.height()
    # 计算右半部分的区域
    right_half_rect = QRect(o_w // 4 * direction, o_h // 4 * index, o_w // 4, o_h // 4)
    # 裁剪图像到右半部分
    right_half_pixmap = original_pixmap.copy(right_half_rect)
    # 更新图像项
    pixmap_item.setPixmap(right_half_pixmap)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    index = 0
    # # 加载图像
    # original_pixmap = QPixmap("F:/pythonProject/ZhanQi_2.0/Asset/Entity/red/soldier/soldier1_move.png")
    # # 获取图像尺寸
    # o_w = original_pixmap.width()
    # o_h = original_pixmap.height()
    # # 计算右半部分的区域
    # right_half_rect = QRect(0, o_h // 4 * index, o_w // 4, o_h // 4)
    # # 裁剪图像到右半部分
    # right_half_pixmap = original_pixmap.copy(right_half_rect)
    # 创建图像项
    pixmap_item = QGraphicsPixmapItem()
    #pixmap_item.setPixmap(right_half_pixmap)

    direction = 0
    #path = "F:/pythonProject/ZhanQi_2.0/Asset/Entity/red/soldier/soldier1_move.png"
    path = "F:/pythonProject/ZhanQi_2.0/Asset/Entity/red/air/plane1_move.png"

    # 创建场景
    scene = QGraphicsScene()
    # 将图像项添加到场景
    scene.addItem(pixmap_item)
    # 创建视图并设置场景
    view = QGraphicsView(scene)
    view.show()
    # 创建定时器来更新动画
    timer = QTimer()
    timer.timeout.connect(lambda: update_animation(direction,path))  # arg1, arg2 是你要传递的参数
    timer.start(150)  # 每 200 毫秒更新一次
    sys.exit(app.exec())
