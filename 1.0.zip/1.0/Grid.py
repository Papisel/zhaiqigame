from PySide6.QtWidgets import QWidget

import Tool
from GridScene import GridScene as Scene
from GridView import GridView as Viewer


class Grid(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        # 地图视窗
        self.viewer = Viewer(self)
        # 底部详情显示
        # self.bottom = Hint()
        # 地图编辑模式
        self.editor_mode = False

    # 导入地图
    def load_map(self, map_path):
        scene = Scene(self)
        self.viewer.setScene(scene)
        scene.load(map_path)
        self.viewer.centerOn(0, 0)

    # 导出地图
    def save_map(self, map):
        basic = map["block_map"]
        w, h = basic["size"]
        for x in range(w):
            for y in range(h):
                item = self.viewer.scene().blocks[(x, y)]
                basic["block"][y][x] = item.terrain
        Tool.save_json("temp/"+basic["name"], map)

    # 接收
    def accept_block(self, coordinate):
        if self.editor_mode:
            name = self.parent().selected
            item = self.viewer.scene().blocks[coordinate]
            item.set_terrain(name)
        else:
            print(coordinate)

    # 设置各部件位置
    def resizeEvent(self, event) -> None:
        w, h = self.width(), self.height()
        self.viewer.setGeometry(0, 0, w, h)
        # self.bottom.setGeometry(0, 0, w, h)


class Hint(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
