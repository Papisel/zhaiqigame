from PySide6.QtCore import Qt
from PySide6.QtWidgets import QGraphicsView, QFrame


# 绘制视图，总体屏幕
class GridView(QGraphicsView):
    def __init__(self, parent=None):
        super().__init__(parent)
        # 不显示滚动条
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        # 移动视角时鼠标的初始位置
        self.drag_position = None
        # 无边框
        self.setFrameShape(QFrame.NoFrame)
        # 背景色
        self.setStyleSheet("background-color: #000000;")

    # 右键拖拽开始
    def mousePressEvent(self, event):
        if event.button() == Qt.RightButton:
            self.drag_position = event.position()
            event.accept()  # 不需要进一步处理
        else:
            super().mousePressEvent(event)

    # 右键拖拽结束
    def mouseReleaseEvent(self, event):
        if event.button() == Qt.RightButton:
            self.drag_position = None
            event.accept()  # 不需要进一步处理
        else:
            super().mouseReleaseEvent(event)

    # 右键拖拽
    def mouseMoveEvent(self, event):
        if event.buttons() == Qt.RightButton:
            # 使用坐标来解决问题
            delta = event.position() - self.drag_position
            self.drag_position = event.position()
            self.horizontalScrollBar().setValue(self.horizontalScrollBar().value() - delta.x())
            self.verticalScrollBar().setValue(self.verticalScrollBar().value() - delta.y())
            event.accept()
        else:
            super().mouseMoveEvent(event)
