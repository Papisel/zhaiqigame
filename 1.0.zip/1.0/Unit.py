from PySide6.QtWidgets import QGraphicsRectItem, QGraphicsPixmapItem
from PySide6.QtCore import Qt, QRect
from PySide6.QtGui import QPixmap, QPen, QColor

import Tool

# 定义方格的宽度和高度,这里是统一像素方格标准为64*64
width, height = 64, 64


# 定义方格类，继承子QGraphicsRectItem矩形框架类
class Unit(QGraphicsRectItem):
    def __init__(self, coordinate: tuple[int, int], unit: str):
        super().__init__()
        # 坐标
        self.coordinate = coordinate
        # 保存方格的单位类型
        self.unit = ''
        # 设置矩形
        x, y = coordinate  # 获取坐标
        rect = QRect(x * width, y * height, width, height)  # 根据坐标和方格的宽度和高度创建一个矩形
        self.setRect(rect)  # 设置为矩形形状
        # 单位绘制
        self.unit_item = QGraphicsPixmapItem(self)  # 创建一个图片项
        self.unit_item.setPos(self.rect().topLeft())  # 设置图片项的位置为方格的左上角
        self.set_unit(unit)  # 根据单位类型设置方格的图片
        # 设置边框
        self.setPen(Qt.NoPen)
        self.setBrush(Qt.NoBrush)  # 设置方格的填充为无

    # 接受鼠标左键
    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:  # 如果按下的是鼠标左键，就触发事件
            print(self.coordinate, self.unit)

    # 设置单位图片及单位
    def set_unit(self, unit):
        # 设置单位
        self.unit = unit
        # 获取图片
        path = terrain2path(self.unit)  # 根据单位类型获取对应的图片路径
        pixmap = QPixmap(path)  # 加载图片
        # 图片拉伸
        pixmap = pixmap.scaled(self.rect().width(), self.rect().height(), Qt.KeepAspectRatio)  # 将图片缩放到和方格一样的大小
        # 显示图像
        self.unit_item.setPixmap(pixmap)


# 根据单位名返回改单位应用图片的地址
def terrain2path(unit):
    path = Tool.where() + "/Asset/Entity"  # 当前文件相对地址下的资源文件夹下的资源文件下
    image_path = path + f'/{unit}.png'  # 指定的单位图片地址
    # attr_path = path + f'/{terrain}.json'
    return image_path  # 返回结果
