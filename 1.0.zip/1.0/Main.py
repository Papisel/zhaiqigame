from PySide6.QtWidgets import QVBoxLayout, QMessageBox, QApplication, QMainWindow, QLabel, QPushButton, QStackedWidget, QWidget, QLineEdit
from PySide6.QtCore import Qt
import Tool
from Grid import Grid
from MapEditor import MapEditor
import mysql.connector
from functools import partial

# 连接到 MySQL 数据库
conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="123456",
    database="game"
)
cursor = conn.cursor()


# 项目主函数进入点，主窗口
class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        # 标题
        self.setWindowTitle("战棋")
        # 工作路径
        self.exe_path = Tool.where()
        # 创建一个堆栈窗口部件
        self.stacked = QStackedWidget()
        # 设置堆栈窗口部件为主窗口的中心部件
        self.setCentralWidget(self.stacked)
        # 设置窗口大小
        self.resize(1280, 720)
        # 设置窗口的最小大小
        self.setMinimumSize(640, 480)

        # 创建登录注册页面并添加到堆栈窗口部件中
        self.page1 = LoginRegisterPage(self)
        self.stacked.addWidget(self.page1)

        # 创建主页并添加到堆栈窗口部件中
        self.home_page = HomePage(self)
        self.stacked.addWidget(self.home_page)

        # 创建战场界面并添加到堆栈窗口部件中
        self.page2 = Grid()
        self.stacked.addWidget(self.page2)

        # 创建地图编辑器
        self.page3 = MapEditor()
        self.stacked.addWidget(self.page3)

        # 创建多人联机页面并添加到堆栈窗口部件中
        self.page4 = MultiplayerPage(self)
        self.stacked.addWidget(self.page4)

        # 创建人机对战页面并添加到堆栈窗口部件中
        self.page5 = AIBattlePage(self)
        self.stacked.addWidget(self.page5)

        # 设置每个页面的索引值
        self.page_index = {
            "login_register_page": 0,
            "home_page": 1,
            "battle_field_page": 2,
            "map_editor_page": 3,
            "multiplayer_page": 4,
            "ai_battle_page": 5
        }

    # 切换到战场界面
    def battle_field(self):
        # 切换到战场界面
        self.stacked.setCurrentIndex(self.page_index["battle_field_page"])
        # 导入地图
        map_path = self.exe_path + "/map/test_map.json"
        self.page2.load_map(map_path)  # 测试用

    # 切换到地图编辑器
    def map_editor(self):
        # 切换到地图编辑器
        self.stacked.setCurrentIndex(self.page_index["map_editor_page"])
        self.button0.clicked.connect(self.window().multiplayer())
    # 切换到多人联机页面
    def multiplayer(self):
        # 切换到多人联机页面
        self.stacked.setCurrentIndex(self.page_index["multiplayer_page"])

    # 切换到人机对战页面
    def ai_battle(self):
        # 切换到人机对战页面
        self.stacked.setCurrentIndex(self.page_index["ai_battle_page"])

    # 切换到主页
    def home(self):
        # 切换到主页
        self.stacked.setCurrentIndex(self.page_index["home_page"])

    def resizeEvent(self, event) -> None:
        w, h = self.width(), self.height()
        self.page1.setGeometry(0, 0, w, h)
        self.home_page.setGeometry(0, 0, w, h)
        self.page2.setGeometry(0, 0, w, h)


class LoginRegisterPage(QWidget):
    def __init__(self, parent):
        super().__init__(parent)
        self.label = QLabel(self)
        self.label.setAlignment(Qt.AlignCenter)
        self.label.setGeometry(0, 0, parent.width(), parent.height())
        self.username_edit = QLineEdit(self)
        self.username_edit.setPlaceholderText("用户名")
        self.username_edit.setGeometry(parent.width() // 2 - 100, parent.height() // 2 - 75, 200, 30)
        self.password_edit = QLineEdit(self)
        self.password_edit.setPlaceholderText("密码")
        self.password_edit.setEchoMode(QLineEdit.Password)
        self.password_edit.setGeometry(parent.width() // 2 - 100, parent.height() // 2 - 25, 200, 30)

        login_button = QPushButton("登录", self)
        login_button.setGeometry(parent.width() // 2 - 100, parent.height() // 2 + 25, 90, 30)
        login_button.clicked.connect(self.login)

        register_button = QPushButton("注册", self)
        register_button.setGeometry(parent.width() // 2 + 10, parent.height() // 2 + 25, 90, 30)
        register_button.clicked.connect(self.open_register_window)
        # 在此处创建注册窗口对象但不显示
        self.register_window = RegisterWindow()

    def login(self):
        username = self.username_edit.text()
        password = self.password_edit.text()
        if not username or not password:
            QMessageBox.warning(self, "警告", "请输入用户名和密码", QMessageBox.Ok)
            return
        try:
            cursor.execute("SELECT * FROM users WHERE username = %s AND password = %s", (username, password))
            user = cursor.fetchone()
            if user:
                self.window().stacked.setCurrentIndex(self.window().page_index["home_page"])  # 登录成功后跳转到主页
            else:
                QMessageBox.warning(self, "警告", "用户名或密码错误", QMessageBox.Ok)
        except Exception as e:
            print("数据库错误:", e)

    def open_register_window(self):
        self.register_window.show()


class RegisterWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("注册")
        self.resize(300, 200)

        layout = QVBoxLayout()

        self.username_edit = QLineEdit()
        self.username_edit.setPlaceholderText("用户名")
        layout.addWidget(self.username_edit)

        self.password_edit = QLineEdit()
        self.password_edit.setPlaceholderText("密码")
        self.password_edit.setEchoMode(QLineEdit.Password)
        layout.addWidget(self.password_edit)

        register_button = QPushButton("注册")
        register_button.clicked.connect(self.register)
        layout.addWidget(register_button)

        self.setLayout(layout)

    def register(self):
        username = self.username_edit.text()
        password = self.password_edit.text()
        if not username or not password:
            QMessageBox.warning(self, "警告", "请输入用户名和密码", QMessageBox.Ok)
            return
        try:
            cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
            if cursor.fetchone():
                QMessageBox.warning(self, "警告", "用户名已存在", QMessageBox.Ok)
                return
            cursor.execute("INSERT INTO users (username, password) VALUES (%s, %s)", (username, password))
            conn.commit()
            QMessageBox.information(self, "成功", "注册成功", QMessageBox.Ok)
            self.close()
        except Exception as e:
            print("数据库错误:", e)


class HomePage(QWidget):
    def __init__(self, parent):
        super().__init__(parent)
        self.label = QLabel(self)
        self.label.setAlignment(Qt.AlignCenter)
        self.label.setGeometry(0, 0, parent.width(), parent.height())
        self.button1 = QPushButton("多人联机", self.label)
        self.button1.clicked.connect(self.multiplayer)
        self.button1.setGeometry(parent.width() // 2 - 100, parent.height() // 2 - 75, 200, 30)
        self.button2 = QPushButton("人机对战", self.label)
        self.button2.clicked.connect(self.ai_battle)
        self.button2.setGeometry(parent.width() // 2 - 100, parent.height() // 2 - 25, 200, 30)
        self.button3 = QPushButton("退出登录", self.label)
        self.button3.clicked.connect(self.logout)
        self.button3.setGeometry(parent.width() // 2 - 100, parent.height() // 2 + 25, 200, 30)

    # 多人联机
    def multiplayer(self):
        # 切换到多人联机页面
        self.window().multiplayer()

    # 人机对战
    def ai_battle(self):
        # 切换到人机对战页面
        self.window().ai_battle()

    # 退出登录
    def logout(self):
        # 切换到登录注册页面
        self.window().stacked.setCurrentIndex(self.window().page_index["login_register_page"])

class MultiplayerPage(QWidget):
    def __init__(self, parent):
        super().__init__(parent)
        self.label = QLabel(self)
        self.label.setAlignment(Qt.AlignCenter)
        self.label.setGeometry(0, 0, parent.width(), parent.height())
        self.button1 = QPushButton("开始游戏", self.label)
        self.button1.clicked.connect(self.start_game)
        self.button1.setGeometry(parent.width() // 2 - 100, parent.height() // 2 - 75, 200, 30)
        self.button2 = QPushButton("编辑地图", self.label)
        self.button2.clicked.connect(self.map_editor)
        self.button2.setGeometry(parent.width() // 2 - 100, parent.height() // 2 - 25, 200, 30)
        self.button3 = QPushButton("退出游戏", self.label)
        self.button3.clicked.connect(self.quit_game)
        self.button3.setGeometry(parent.width() // 2 - 100, parent.height() // 2 + 25, 200, 30)

    # 开始游戏
    def start_game(self):
        # 切换到战场界面
        self.window().battle_field()

    # 打开地图编辑器
    def map_editor(self):
        self.window().map_editor()

    # 退出游戏
    def quit_game(self):
        # 切换到主页
        self.window().stacked.setCurrentIndex(self.window().page_index["home_page"])

class AIBattlePage(QWidget):
    def __init__(self, parent):
        super().__init__(parent)
        self.label = QLabel(self)
        self.label.setAlignment(Qt.AlignCenter)
        self.label.setGeometry(0, 0, parent.width(), parent.height())
        self.button1 = QPushButton("简单", self.label)
        self.button1.clicked.connect(self.start_easy_game)
        self.button1.setGeometry(parent.width() // 2 - 100, parent.height() // 2 - 75, 200, 30)
        self.button2 = QPushButton("中等", self.label)
        self.button2.clicked.connect(self.start_medium_game)
        self.button2.setGeometry(parent.width() // 2 - 100, parent.height() // 2 - 25, 200, 30)
        self.button3 = QPushButton("困难", self.label)
        self.button3.clicked.connect(self.start_hard_game)
        self.button3.setGeometry(parent.width() // 2 - 100, parent.height() // 2 + 25, 200, 30)
        self.button3 = QPushButton("退出游戏", self.label)
        self.button3.clicked.connect(self.quit_game)
        self.button3.setGeometry(parent.width() // 2 - 100, parent.height() // 2 + 75, 200, 30)

    # 开始简单难度游戏
    def start_easy_game(self):
        # 在这里添加开始简单难度游戏的逻辑
        pass

    # 开始中等难度游戏
    def start_medium_game(self):
        # 在这里添加开始中等难度游戏的逻辑
        pass

    # 开始困难难度游戏
    def start_hard_game(self):
        # 在这里添加开始困难难度游戏的逻辑
        pass

    def quit_game(self):
        # 切换到主页
        self.window().stacked.setCurrentIndex(self.window().page_index["home_page"])

# 主程序入口
if __name__ == "__main__":
    # 创建应用程序对象
    app = QApplication()
    # 创建主窗口对象
    window = MainWindow()
    # 显示主窗口
    window.show()
    # 进入应用程序的主循环
    app.exec()
