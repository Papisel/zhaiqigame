from PySide6.QtWidgets import QGraphicsRectItem, QGraphicsPixmapItem
from PySide6.QtCore import Qt, QRect
from PySide6.QtGui import QPixmap, QPen, QColor

import Tool

# 定义方格的宽度和高度,这里是统一像素方格标准为64*64
width, height = 64, 64


# 定义方格类，继承子QGraphicsRectItem矩形框架类
class Block(QGraphicsRectItem):
    def __init__(self, coordinate: tuple[int, int], terrain: str):
        super().__init__()
        # 坐标
        self.coordinate = coordinate
        # 保存方格的地形类型
        self.terrain = ''
        # 设置矩形
        x, y = coordinate  # 获取坐标
        rect = QRect(x * width, y * height, width, height)  # 根据坐标和方格的宽度和高度创建一个矩形
        self.setRect(rect)  # 设置为矩形形状
        # 地形绘制
        self.terrain_item = QGraphicsPixmapItem(self)  # 创建一个图片项
        self.terrain_item.setPos(self.rect().topLeft())  # 设置图片项的位置为方格的左上角
        self.set_terrain(terrain)  # 根据地形类型设置方格的图片
        # 设置边框
        self.setPen(QPen(QColor("#ffffff"), 2))
        self.setBrush(Qt.NoBrush)  # 设置方格的填充为无

    # 接受鼠标左键
    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:  # 如果按下的是鼠标左键，就触发事件
            grid = self.scene().views()[0].parent()
            grid.accept_block(self.coordinate)  # 打印方格的坐标

    # 地图编辑模式
    def clean_terrain(self):
        self.terrain = ''
        # 清除显示的图像
        pixmap = QPixmap()
        self.terrain_item.setPixmap(pixmap)

    # 设置地形图片及地形
    def set_terrain(self, terrain):
        # 设置地形
        self.terrain = terrain
        # 地形不为空
        if terrain:
            # 获取图片
            path = terrain2path(self.terrain)  # 根据地形类型获取对应的图片路径
            pixmap = QPixmap(path)  # 加载图片
            # 图片拉伸
            pixmap = pixmap.scaled(self.rect().width(), self.rect().height(), Qt.KeepAspectRatio)  # 将图片缩放到和方格一样的大小
            # 显示图像
            self.terrain_item.setPixmap(pixmap)
        else:
            self.clean_terrain()


# 根据地形名返回改地形应用图片的地址
def terrain2path(terrain):
    path = Tool.where() + "/Asset/Terrain"  # 当前文件相对地址下的资源文件夹下的资源文件下
    image_path = path + f'/{terrain}.png'  # 指定的地形图片地址
    # attr_path = path + f'/{terrain}.json'
    return image_path  # 返回结果
