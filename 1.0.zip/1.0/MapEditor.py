from PySide6.QtCore import Qt
from PySide6.QtGui import QFont, QPixmap
from PySide6.QtWidgets import QPushButton, QLineEdit, QListWidget, QWidget, QLabel, QListWidgetItem

import Tool
from Grid import Grid

# 设置基本间距
left = 8
up = 8

# 设置输入框基本长宽
labelWidth = 15
labelHeight = 20

# 设置输入框基本长宽
edit1Width = 50
edit1Height = 20

# 设置按钮基本长宽
buttonWidth = 60
buttonHeight = 30


# 创建指定名字、指定大小的空白地图用于初始显示
def blank_map(name, length, width):
    data = dict()
    data["block_map"] = {"name": name, "size": [length, width], "block": []}
    for y in range(width):
        data["block_map"]["block"].append(list())
        for _ in range(length):
            data["block_map"]["block"][y].append(str())
    return data


class MapEditor(QWidget):
    def __init__(self):
        super().__init__()
        # 地形选择器
        self.list_widget = QListWidget(self)
        self.list_widget.itemClicked.connect(self.select_terrain)
        self.load_terrain()

        # 创建一个QFont对象
        font = QFont()
        font.setPointSize(14)  # 设置字体大小为14

        self.labelHand = QLabel(self)
        self.labelHand.setFont(font)  # 设置字体
        self.labelHand.setText("地 图 编 辑 器")

        # 输入地图名
        self.label0 = QLabel(self)
        self.label0.setText("地图名：")

        self.line_edit0 = QLineEdit(self)

        # 输入地图长宽
        self.label1 = QLabel(self)
        self.label1.setText("列：")

        self.label2 = QLabel(self)
        self.label2.setText("行：")

        self.line_edit1 = QLineEdit(self)
        self.line_edit2 = QLineEdit(self)

        # 返回
        self.button0 = QPushButton("返回", self)
        self.button0.clicked.connect(self.quit)
        # 新建地图
        self.button1 = QPushButton("新建地图", self)
        self.button1.clicked.connect(self.new_map)
        # 保存地图
        self.button2 = QPushButton("保存地图", self)
        self.button2.clicked.connect(self.save_map)
        # 地图视窗
        self.viewer = Grid(self)
        self.viewer.editor_mode = True
        # 当前选择的
        self.selected = ''

    # 布局
    def resizeEvent(self, event) -> None:
        w, h = self.width(), self.height()

        widgetWidth = 224
        widgetHeight = h - 200

        viewWidth = w - widgetWidth - left * 3
        viewHeight = h - up * 2

        AllUp = up
        AllLeft = left
        # 左上角坐标（x,y），宽，高
        # 返回按钮
        self.button0.setGeometry(left, AllUp, buttonWidth, buttonHeight)

        self.labelHand.setGeometry(buttonWidth + left * 3, up * 2, labelWidth * 10, labelHeight)

        # 块选择框
        AllUp += buttonHeight
        self.list_widget.setGeometry(left, up + AllUp, widgetWidth, widgetHeight)

        # 地图名输入框
        AllUp += widgetHeight + up
        self.label0.setGeometry(AllLeft, up + AllUp, labelWidth * 3, labelHeight)
        AllLeft += labelWidth * 3
        self.line_edit0.setGeometry(AllLeft + left, up + AllUp, edit1Width * 2, edit1Height)

        # 长宽输入框
        AllLeft = left
        AllUp += edit1Height + up
        self.label1.setGeometry(AllLeft + left, up + AllUp, labelWidth, labelHeight)
        AllLeft += labelWidth + left * 4.6
        self.line_edit1.setGeometry(AllLeft, up + AllUp, edit1Width, edit1Height)
        AllLeft = left
        AllUp += edit1Height + up
        self.label2.setGeometry(AllLeft + left, up + AllUp, labelWidth, labelHeight)
        AllLeft += labelWidth + left * 4.6
        self.line_edit2.setGeometry(AllLeft, up + AllUp, edit1Width, edit1Height)

        # 新建地图按钮
        AllUp += edit1Height + up * 2
        AllLeft = left
        self.button1.setGeometry(left, AllUp + up, buttonWidth, buttonHeight)

        # 保存地图按钮
        AllLeft += buttonWidth + left * 2
        self.button2.setGeometry(AllLeft, AllUp + up, buttonWidth, buttonHeight)

        AllLeft = widgetWidth + left
        AllUp = up
        self.viewer.setGeometry(AllLeft + left, AllUp, viewWidth, viewHeight)

    # 导入文件夹全部地形
    def load_terrain(self):
        path = Tool.where() + "/Asset/Terrain"
        fs = Tool.get_all(path)
        for f in fs:
            item = Item(f)
            list_item = QListWidgetItem()
            list_item.setSizeHint(item.size())
            self.list_widget.addItem(list_item)
            self.list_widget.setItemWidget(list_item, item)

    def select_terrain(self):
        selected_items = self.list_widget.selectedItems()
        if selected_items:
            item = self.list_widget.itemWidget(selected_items[0])

            # print(item.path)
            self.selected = item.name

    # 退出地图编辑器
    def quit(self):
        self.line_edit0.clear()
        self.line_edit1.clear()
        self.line_edit2.clear()
        self.window().multiplayer()

    # 新建地图
    def new_map(self):
        mapName = self.line_edit0.text()
        length = self.line_edit1.text()
        width = self.line_edit2.text()
        # 检查length和width是否都是整型数字
        if mapName and length.isdigit() and width.isdigit():
            map = blank_map(mapName, int(length), int(width))
            self.viewer.load_map(map)

    # 保存地图
    def save_map(self):
        mapName = self.line_edit0.text()
        length = self.line_edit1.text()
        width = self.line_edit2.text()
        # 检查length和width是否都是整型数字
        if mapName and length.isdigit() and width.isdigit():
            map = blank_map(mapName, int(length), int(width))
            self.viewer.save_map(map)


# 块选择框类
class Item(QWidget):
    def __init__(self, path):
        super().__init__()
        # 路径
        self.path = path
        self.name = path.split('/')[-1].split('.')[0]
        # 框架
        self.label1 = self.terrain_label(path)
        self.label2 = self.name_label()
        # 几何
        self.set_size(224, 70)

    def terrain_label(self, path):
        label = QLabel(self)
        icon = QPixmap(path)
        label.setPixmap(icon)
        # label.setScaledContents(True)
        return label

    def name_label(self):
        label = QLabel(self)
        label.setText(self.name)
        font = QFont()
        font.setPixelSize(12)
        label.setFont(font)
        label.setAlignment(Qt.AlignCenter)
        return label

    def set_size(self, w, h):
        self.resize(w, h)
        h -= 6
        self.label1.setGeometry(0, 3, h, h)
        self.label2.setGeometry(h, 3, w - h, h)
