from PySide6.QtGui import QColor, QBrush
from PySide6.QtWidgets import QGraphicsScene

from Block import Block
import Tool


# 绘制场景，屏幕中的内容
class GridScene(QGraphicsScene):
    def __init__(self, parent):
        super().__init__(parent)
        # 设置背景颜色
        self.setBackgroundBrush(QBrush(QColor("#000000")))
        # 设置背景大小
        length = 64 * 20  # 注意长宽，左上角开始，右下角结束，过短将在原点结束
        self.setSceneRect(-length, -length, 4 * length, 4 * length)
        # 所有的地形格
        self.blocks: [tuple, Block] = {}

    # 导入地图并渲染
    def load(self, map_path):
        # 导入地形地图
        if isinstance(map_path, str):
            basic = Tool.load_json(map_path)["block_map"]
        # 不是地图路径，地图本体
        else:
            basic = map_path["block_map"]
        w, h = basic["size"]
        for x in range(w):
            for y in range(h):
                # 修改后，符合文件的格式按照其视觉预期显示地图
                # 只是修改读取地图文件时候的顺序，最终得到这张地图是没有影响的
                # 不过有一点，就是之后如果加一个地图编辑功能，那要记得注意这个
                # 或者再给这里改回来，毕竟现在视为了测试用
                # 这段注释留一下，避免后面忘了
                # item = Block((x, y), basic["block"][x][y])
                item = Block((x, y), basic["block"][y][x])
                self.addItem(item)
                self.blocks[(x, y)] = item
        # 导入单位
